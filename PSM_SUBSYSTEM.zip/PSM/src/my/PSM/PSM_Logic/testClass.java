package my.PSM.PSM_Logic;



import my.PSM.PSM_Logic.PrefilledScheduleForm;
import my.PSM.PSM_Logic.ScheduleForm;
import my.PSM.PSM_Logic.appController;




public class testClass {


	public boolean msg = false;
	private static boolean msgT = true;
	private String username;
	private String password;
	private static boolean dataRec = true;
	private static boolean schedule = false;
	private static boolean setup = false;
	private static boolean logout = false;
	private static boolean courseSelect = true;
	private static boolean data = false;
	
	public String [] listCourses;


	public int defCourseID;
	public String newCourseStart;
	public String newCourseEnd; 
	public String newMonStart;
	public String newMonEnd;
	public String newTueStart;
	public String newTueEnd; 
	public String newWedStart;
	public String newWedEnd; 
	public String newThuStart;
	public String newThuEnd; 
	public String newFriStart;
	public String newFriEnd;
	public String newSatStart;
	public String newSatEnd;
	public int newCourseID;
	public String newCourseName;
	public String newSemester;
	public String newSub;
	
	public testClass() 
	{

	
	}
	
	

	public void Initiate_Login_Form()
	{
	
	} 

	public void Initiate_IncorrectLogin()
	{
		
	}

	public void Initiate_MainMenu() 
	{
		
	}

	public boolean dataRec()
	{
		return dataRec;
	}

	public void setdataRec(boolean condition)
	{
		dataRec = condition;
	}

	public boolean editSchedSelected() 
	{
		return schedule;
	}

	public boolean InitSetupSelected() 
	{
		return setup;
	}

	public boolean logoutSelected() 
	{
		return logout;
	}


	public void Initiate_Logout() 
	{
		
	}

	public void Course_Select_Form() 
	{
		
	}
	public void editSched() 
	{
		
	}

	public boolean courseSelected() 
	{
		return false;
	}

	public void setCourseSelected(boolean b) 
	{
		courseSelect = b;
	}

	public int getSelection() 
	{
		return 0;
	}

	public boolean passwordLock() 
	{
		return false;
	}


	public String getUsername()
	{
		
		username = appController.db.getUsername();
		
		return username;
	}
	
	
	public String getPassword()
	{
		
		username = appController.db.getPassword();
		
		return username;
	}

	public void Pre_Filled_Form(int courseSel, String defSub, String defCourseName, String defSemester,
			String defCourseStart, String defCourseEnd, String defMonStart, String defMonEnd, String defTueStart,
			String defTueEnd, String defWedStart, String defWedEnd, String defThuStart, String defThuEnd,
			String defFriStart, String defFriEnd, String defSatStart, String defSatEnd) 
	{

	}
	

	public void launchInitial() {

	}

	
	// First Login from spilt main
	public boolean dataReceived() {
		
		return data;
	}

	public void setDataRec(boolean b) {
		dataRec = b;
	}

	public void FifteenMinWarning() {
		// TODO Auto-generated method stub
		
	}

	public void endClassWarning() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
