package my.PSM.testPack;


import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.mockito.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.mysql.cj.Messages;
import com.mysql.cj.xdevapi.Statement;
import com.mysql.jdbc.Connection;

import my.PSM.PSM_Logic.Authenticate;
import my.PSM.PSM_Logic.appController;
import my.PSM.PSM_Logic.testClass;
import my.PSM.PSM_Storage.DBConnection;

public class appControllerTest {

	@Mock
	DBConnection dbCon;
	@Mock
	testClass tcMock;
	@Mock
	Authenticate authMock;



	appController controller;
	DBConnection dbCon2;
	testClass tc;



	@Before
	public void setUp() throws Exception 
	{
		controller = new appController();
		dbCon2 = new DBConnection();
		tc = new testClass();

		dbCon = mock(DBConnection.class);
		authMock = mock(Authenticate.class);
		tcMock = mock(testClass.class);


		controller.setDB(dbCon);
		controller.setAuthenticate(authMock);
		controller.setTestClass(tcMock);
	}

	@After
	public void tearDown() throws Exception 
	{
		controller = null;
	}


	//Test ID: appController_Subsystem_Sunny001
	//Purpose: Test if getData is able to retrieve mocked data from DBConnection.
	//Test Setup: See Table 1 
	//Input: defSub = "ENC", defSemester = "Spring", defCourseName = "English",
	//defCourseStart = "01/08/19", defCourseEnd = "05/01/19", defMonStart = "15:00", defMonEnd = "16:00", defTueStart = "15:00",
	//defTueEnd = "16:00", defWedStart = "15:00", defWedEnd = "16:00", defThuStart = "15:00", defThuEnd = "16:00",
	//defFriStart = "15:00", defFriEnd = "16:00", defSatStart = "15:00", defSatEnd = "16:00"
	//Expected Output: A pass since dbcon will returned the mocked data inputed.

	@Test
	public void testGetDataSunny001() 
	{
		// Table 1
		String defSub = "ENC";
		String defSemester = "Spring";
		String defCourseName = "English";
		String defCourseStart = "01/08/19";
		String defCourseEnd = "05/01/19";
		String defMonStart = "15:00";
		String defMonEnd = "16:00";
		String defTueStart = "15:00";
		String defTueEnd = "16:00";
		String defWedStart = "15:00";
		String defWedEnd = "16:00";
		String defThuStart = "15:00";
		String defThuEnd = "16:00";
		String defFriStart = "15:00";
		String defFriEnd = "16:00";
		String defSatStart = "15:00";
		String defSatEnd = "16:00";



		String[] allValues =
			{
					defSub,
					defSemester,
					defCourseName,
					defCourseStart,
					defCourseEnd,
					defMonStart,
					defMonEnd,
					defTueStart,
					defTueEnd,
					defWedStart,
					defWedEnd,
					defThuStart,
					defThuEnd,
					defFriStart,
					defFriEnd,
					defSatStart,
					defSatEnd
			};



		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);

		controller.getData(1101);

		assertArrayEquals(allValues, controller.getDataValues());


	}


	//Test ID: appController_Subsystem_Sunny002
	//Purpose: To test if the checkClear method is able to verify the dates added.
	//Test setup: See Table 1
	//Input: "01/08/19", "01/08/19", "01/08/19"
	//Expected output: This will return true since the dates are before today (01/08/19)
	@Test
	public void testCheckClearSunny002() 
	{
		// Table 1
		ArrayList<String> date = new ArrayList<String>();
		date.add("01/08/19");
		date.add("01/08/19");
		date.add("01/08/19");

		when(dbCon.getEndDates()).thenReturn(date);
		assertTrue(controller.checkClear());
		verify(dbCon).getEndDates();
	}


	//Test ID: appController_Subsystem_Rainy003
	//Purpose: To test if CheckTimes method will return false.
	//Test Setup: See Table 1
	//Input: date.add(1101), defSub = "ENC", defSemester = "Spring", defCourseName = "English",
	//defCourseStart = "01/08/19", defCourseEnd = "05/01/19", defMonStart = "15:00", defMonEnd = "16:00", defTueStart = "15:00",
	//defTueEnd = "16:00", defWedStart = "15:00", defWedEnd = "16:00", defThuStart = "15:00", defThuEnd = "16:00",
	//defFriStart = "15:00", defFriEnd = "16:00", defSatStart = "15:00", defSatEnd = "16:00"
	//Expected Output: This will be false since the return value of isNull is false. 
	@Test
	public void testCheckTimesSunny003() 
	{
		// Table 1
		ArrayList<Integer> date = new ArrayList<Integer>();
		date.add(1101);
		String defSub = "ENC";
		String defSemester = "Spring";
		String defCourseName = "English";
		String defCourseStart = "01/08/19";
		String defCourseEnd = "05/01/19";
		String defMonStart = "15:00";
		String defMonEnd = "16:00";
		String defTueStart = "15:00";
		String defTueEnd = "16:00";
		String defWedStart = "15:00";
		String defWedEnd = "16:00";
		String defThuStart = "15:00";
		String defThuEnd = "16:00";
		String defFriStart = "15:00";
		String defFriEnd = "16:00";
		String defSatStart = "15:00";
		String defSatEnd = "16:00";

		when(dbCon.getCourses()).thenReturn(date);
		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);


		assertFalse(controller.checkTimes());
	}


	//FAILED
	//Test ID: appController_Subsystem_Sunny004
	//Purpose: Test if get data is able to retrieve data from a non-mocked db call.
	//Test Setup: See Table 1
	//Input: defSub = "ENC", defSemester = "Spring", defCourseName = "English",
	//defCourseStart = "01/08/19", defCourseEnd = "05/01/19", defMonStart = "15:00", defMonEnd = "16:00", defTueStart = "15:00",
	//defTueEnd = "16:00", defWedStart = "15:00", defWedEnd = "16:00", defThuStart = "15:00", defThuEnd = "16:00",
	//defFriStart = "15:00", defFriEnd = "16:00", defSatStart = "15:00", defSatEnd = "16:00"
	//Expected Output: A test passed since the inputs should match the returns placed into the DBConnection methods called.
	@Test
	public void testGetDataSunny004() 
	{

		// Table 1
		String defSub = "ENC";
		String defSemester = "Spring";
		String defCourseName = "English";
		String defCourseStart = "01/08/19";
		String defCourseEnd = "05/01/19";
		String defMonStart = "15:00";
		String defMonEnd = "16:00";
		String defTueStart = "15:00";
		String defTueEnd = "16:00";
		String defWedStart = "15:00";
		String defWedEnd = "16:00";
		String defThuStart = "15:00";
		String defThuEnd = "16:00";
		String defFriStart = "15:00";
		String defFriEnd = "16:00";
		String defSatStart = "15:00";
		String defSatEnd = "16:00";



		String[] allValues =
			{
					defSub,
					defSemester,
					defCourseName,
					defCourseStart,
					defCourseEnd,
					defMonStart,
					defMonEnd,
					defTueStart,
					defTueEnd,
					defWedStart,
					defWedEnd,
					defThuStart,
					defThuEnd,
					defFriStart,
					defFriEnd,
					defSatStart,
					defSatEnd
			};




		dbCon2.fetchCourseSubj(1101);
		dbCon2.fetchCourseSemester(1101);
		dbCon2.fetchCourseName(1101);
		dbCon2.fetchCourseStart(1101);
		dbCon2.fetchCourseEnd(1101);
		dbCon2.fetchStartMon(1101);
		dbCon2.fetchEndMon(1101);
		dbCon2.fetchStartTue(1101);
		dbCon2.fetchEndTue(1101);
		dbCon2.fetchStartWed(1101);
		dbCon2.fetchEndWed(1101);
		dbCon2.fetchStartThu(1101);
		dbCon2.fetchEndThu(1101);
		dbCon2.fetchStartFri(1101);
		dbCon2.fetchEndFri(1101);
		dbCon2.fetchStartSat(1101);
		dbCon2.fetchEndSat(1101);

		dbCon2.fetchCourses();
		controller.getData(1101);

		assertArrayEquals(allValues, controller.getDataValues());


	}



	//Test ID: appController_Subsystem_Sunny005
	//Purpose: Test the loggedin method from the main using the testClass non-mocked to retrieve the data.
	//Test Setup: Test the loggedin method from the main using the testClass non-mocked to retrieve the data.
	//Input: user = "Clarke", password = "Peter123"
	//Expected Output: True
	@Test
	public void testLoggedinSunny005() 
	{

		doNothing().when(tcMock).Initiate_Login_Form();
		tcMock.msg = true;
		when(tcMock.dataReceived()).thenReturn(true);
		tcMock.getUsername();
		tcMock.getPassword();
		when(authMock.validate_Login()).thenReturn(true);
		when(dbCon.connect("Clarke", "Peter123")).thenReturn(0);
		assertTrue(controller.loggedin());
	}


	//Test ID: appController_Subsystem_Sunny006
	//Purpose: Test the loggedin method for the main to verify it works with a non-mocked db call.
	//Test Setup: user = "Clarke", password = "Peter123"
	//Input: Username: "Clarke" PW: "Peter123"
	//Expected Output: True
	@Test
	public void testLogInSunny006() 
	{
		dbCon2.connect("Clarke", "Peter123");

		appController.LogIn(dbCon2);

		assertTrue(controller.getLoggedIn());
	}


	//Test ID: appController_Subsystem_Sunny007
	//Purpose: To test the logoutsel which is the other part of the main.
	//Test Setup: In this setup calls to testClass were mocked.
	//Input: Pre_Filled_Form(4555,"COP","Prog. Languages","Spring","01/08/2019",
	//"04/20/2019","15:00","16:30",null,null,"15:00",
	// "16:30",null,null,null,null,null,null)
	//Expected Output: This is suppose to pass since the dependencies are mock. 
	@Test
	public void testLogoutselSunny007() 
	{

		when(tcMock.dataRec()).thenReturn(true);
		when(tcMock.editSchedSelected()).thenReturn(true);
		when(tcMock.InitSetupSelected()).thenReturn(false);
		when(tcMock.logoutSelected()).thenReturn(false);
		doNothing().when(tcMock).Course_Select_Form();
		when(tcMock.courseSelected()).thenReturn(true);
		when(tcMock.getSelection()).thenReturn(4555);
		doNothing().when(tcMock).Pre_Filled_Form(4555,"COP","Prog. Languages","Spring","01/08/2019",
				"04/20/2019","15:00","16:30",null,null,"15:00",
				"16:30",null,null,null,null,null,null);
		when(tcMock.dataRec()).thenReturn(true);
		assertFalse(appController.logoutsel());


	}


	//Test ID: appController_Subsystem_Rainy001
	//Purpose: Test getData method returns false with bad data.
	//Test Setup: See Table 1
	//Input: defSub = "", defSemester = "Spring", defCourseName = "English",
	//defCourseStart = "01/08/19", defCourseEnd = "05/01/19", defMonStart = "15:00", defMonEnd = "16:00", defTueStart = "15:00",
	//defTueEnd = "16:00", defWedStart = "15:00", defWedEnd = "16:00", defThuStart = "15:00", defThuEnd = "16:00",
	//defFriStart = "15:00", defFriEnd = "16:00", defSatStart = "15:00", defSatEnd = "16:00"
	//Expected Output: A failed test since the data imputed is different. 
	@Test
	public void testGetDataRainy001() 
	{
		// Table 1
		String defSub = "";
		String defSemester = "Spring";
		String defCourseName = "English";
		String defCourseStart = "01/08/19";
		String defCourseEnd = "05/01/19";
		String defMonStart = "15:00";
		String defMonEnd = "16:00";
		String defTueStart = "15:00";
		String defTueEnd = "16:00";
		String defWedStart = "15:00";
		String defWedEnd = "16:00";
		String defThuStart = "15:00";
		String defThuEnd = "16:00";
		String defFriStart = "15:00";
		String defFriEnd = "16:00";
		String defSatStart = "15:00";
		String defSatEnd = "16:00";



		String[] allValues =
			{
					defSub,
					defSemester,
					defCourseName,
					defCourseStart,
					defCourseEnd,
					defMonStart,
					defMonEnd,
					defTueStart,
					defTueEnd,
					defWedStart,
					defWedEnd,
					defThuStart,
					defThuEnd,
					defFriStart,
					defFriEnd,
					defSatStart,
					defSatEnd
			};



		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);

		controller.getData(1101);

		assertFalse(allValues.equals(controller.getDataValues()));


	}	



	//Test ID: appController_Subsystem_Rainy002
	//Purpose: This will test if the loggedin method will return an incorrect login form. 
	//Test Setup: user = "Clarke", password = "Peter123"
	//Input: authenticate will return false
	//Expected Output: True since the user will be denied access.
	@Test
	public void testLoggedinRainy002() 
	{

		doNothing().when(tcMock).Initiate_Login_Form();
		tcMock.msg = true;
		tcMock.msg = true;
		when(tcMock.dataReceived()).thenReturn(true);
		tcMock.getUsername();
		tcMock.getPassword();
		when(authMock.validate_Login()).thenReturn(false);
		when(dbCon.connect("Clarke", "Peter123")).thenReturn(0);		
		doNothing().when(tcMock).Initiate_IncorrectLogin();
		tcMock.msg = true;

		assertTrue(controller.loggedin());


	}

	//Test ID: appController_Subsystem_Rainy003
	//Purpose: This will be true since the return value of isNull is true.
	//Test Setup: See Table 1
	//Input: date.add(1101), defSub = "", defSemester = "", defCourseName = "",
	//defCourseStart = "", defCourseEnd = "", defMonStart = "", defMonEnd = "", defTueStart = "",
	//defTueEnd = "", defWedStart = "", defWedEnd = "", defThuStart = "", defThuEnd = "",
	//defFriStart = "", defFriEnd = "", defSatStart = "", defSatEnd = ""
	//Expected Output: This will be true since the return value of isNull is true. 

	@Test
	public void testCheckTimesRainy003() {

		// Table 1
		ArrayList<Integer> date = new ArrayList<Integer>();
		date.add(1101);
		String defSub = "";
		String defSemester = "";
		String defCourseName = "";
		String defCourseStart = "";
		String defCourseEnd = "";
		String defMonStart = "";
		String defMonEnd = "";
		String defTueStart = "";
		String defTueEnd = "";
		String defWedStart = "";
		String defWedEnd = "";
		String defThuStart = "";
		String defThuEnd = "";
		String defFriStart = "";
		String defFriEnd = "";
		String defSatStart = "";
		String defSatEnd = "";

		when(dbCon.getCourses()).thenReturn(date);
		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);

		assertTrue(controller.checkTimes());
	}

	//Test ID: appController_Subsystem_Rainy004
	//Purpose: To test if the checkClear method is able to verify the dates added are false.
	//Test Setup: In this setup DBConnection was mocked to test if checkClear is able to add dates. 
	//Input: "03/08/19", "03/08/19", "03/08/19"
	//Expected output: False since the dates are after today's date (03/08/19)
	@Test
	public void testCheckClearRainy004() {
		// Table 1
		ArrayList<String> date = new ArrayList<String>();
		date.add("03/08/19");
		date.add("03/08/19");
		date.add("03/08/19");

		when(dbCon.getEndDates()).thenReturn(date);
		assertTrue(controller.checkClear());
		verify(dbCon).getEndDates();
	}


	//Test ID: appController_Subsystem_Rainy005
	//Purpose: To test the logoutsel which is the other part of the main.
	//Test Setup: In this setup calls to testClass were mocked.
	//Input: boolean values
	//Expected Output: This is suppose to pass but test fails. 
	@Test
	public void testLogoutselRainy005() 
	{
		when(tcMock.dataRec()).thenReturn(true);
		when(tcMock.editSchedSelected()).thenReturn(false);
		when(tcMock.InitSetupSelected()).thenReturn(false);
		when(tcMock.logoutSelected()).thenReturn(true);
		doNothing().when(authMock).logout();
		doNothing().when(tcMock).Initiate_Logout();
		assertTrue(appController.logoutsel());
	}

	//Test ID: PappController_Subsystem_Rainy006
	//Purpose: To Test the LogIn method
	//Test Setup: In this setup DBConnection is mocked to return bad data.
	//Input: user = "bad", pass = "3333"
	//Expected Output: This will be false since the username and password are not valid
	@Test
	public void testLogInRainy006()
	{
		// Table 2
		when(dbCon.connect("bad", "3333")).thenReturn(5);

		controller.LogIn(dbCon);
		assertTrue(controller.getLoggedIn());
	}



}	
