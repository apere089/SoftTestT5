/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.PSM.PSM_Storage;

import java.util.*;

/**
 *
 * @author clarkep
 */
public class DtaStoreFacade {
	
	DBConnection myDB = new DBConnection();
	
    public DtaStoreFacade() {
    	myDB.connect("user1", "1234");
    }
    
    // Test connect() function
    public int connectFacade(String user, String pw)
    {
    	return myDB.connect(user, pw);
    }
    // Test disconnect() function
    public int disconnectFacade()
    {
    	return myDB.disconnect();
    }
    // Test fetchCourseID() function
    public int fetchCourseIDFacade(int courseID)
    {
    	return myDB.fetchCourseID(courseID);
    }
    // Test getEndDates() function
    public ArrayList<String> getEndDatesFacade()
    {
    	return myDB.getEndDates();
    }
    // Test getCourse() function
    public ArrayList<Integer> getCoursesFacade()
    {
    	return myDB.getCourses();
    }
    //Not tested as this method was not implemented.
    // Test fetchCourses() function
    public String fetchCoursesFacade()
    {
    	return myDB.fetchCourses();
    }
    // Test fetchCourseSubj() function
    public String fetchCourseSubjFacade(int courseID)
    {
    	return myDB.fetchCourseSubj(courseID);
    }
    // Test fetchCourseName() function
    public String fetchCourseNameFacade(int courseID)
    {
    	return myDB.fetchCourseName(courseID);
    }
    // Test fetchCourseSemester() function
    public String fetchCourseSemesterFacade(int courseID)
    {
    	return myDB.fetchCourseSemester(courseID);
    }
    // Test fetchCourseStart() function
    public String fetchCourseStartFacade(int courseID)
    {
    	return myDB.fetchCourseStart(courseID);
    }
    // Test fetchCourseEnd() function
    public String fetchCourseEndFacade(int courseID)
    {
    	return myDB.fetchCourseEnd(courseID);
    }
    // Test fetchStartMon() function
    public String fetchStartMonFacade(int courseID)
    {
    	return myDB.fetchStartMon(courseID);
    }
    // Test fetchEndMon() function
    public String fetchEndMonFacade(int courseID)
    {
    	return myDB.fetchEndMon(courseID);
    }
    // Test fetchStartTue() function
    public String fetchStartTueFacade(int courseID)
    {
    	return myDB.fetchStartTue(courseID);
    }
    // Test fetchEndTue() function
    public String fetchEndTueFacade(int courseID)
    {
    	return myDB.fetchEndTue(courseID);
    }
    // Test fetchStartWed() function
    public String fetchStartWedFacade(int courseID)
    {
    	return myDB.fetchStartWed(courseID);
    }
    // Test fetchEndWed() function
    public String fetchEndWedFacade(int courseID)
    {
    	return myDB.fetchEndWed(courseID);
    }
    // Test fetchStartThu() function
    public String fetchStartThuFacade(int courseID)
    {
    	return myDB.fetchStartThu(courseID);
    }
    // Test fetchEndThu() function
    public String fetchEndThuFacade(int courseID)
    {
    	return myDB.fetchEndThu(courseID);
    }
    // Test fetchStartFri() function
    public String fetchStartFriFacade(int courseID)
    {
    	return myDB.fetchStartFri(courseID);
    }
    // Test fetchEndFri() function
    public String fetchEndFriFacade(int courseID)
    {
    	return myDB.fetchEndFri(courseID);
    }
    // Test fetchStartSat() function
    public String fetchStartSatFacade(int courseID)
    {
    	return myDB.fetchStartSat(courseID);
    }
    // Test fetchEndSat() function
    public String fetchEndSatFacade(int courseID)
    {
    	return myDB.fetchEndSat(courseID);
    }
    // Test storeClassInfo() function
    public int storeClassInfoFacade(int courseID, String courseSubj, String courseName, String semester)
    {
    	return myDB.storeClassInfo(courseID, courseSubj, courseName, semester);
    }
    // Test storeClassSched() function
    public int storeClassSchedFacade(int courseID, String startDate, String endDate, String startMon, String endMon,
            String startTue, String endTue, String startWed, String endWed, String startThu, String endThu, 
            String startFri, String endFri, String startSat, String endSat)
    {
    	return myDB.storeClassSched(courseID, startDate, endDate, startMon, endMon, startTue, 
    			endTue, startWed, endWed, startThu, endThu, startFri, endFri, startSat, endSat);
    }
    // Test clearDatabase() function
    public void clearDatabaseFacade() 
    {
    	myDB.clearDatabase();
    }
    /*
    public static void main(String[] args) {
    	DtaStoreFacade fac = new DtaStoreFacade();
    	 System.out.println(fac.fetchCourseIDFacade(4555));
    }
    */
}
