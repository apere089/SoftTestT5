package my.PSM.PSM_Storage;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DtaStoreFacadeTest {
	
	private DtaStoreFacade newFc;
	
	@BeforeEach
	void setUp() throws Exception {
		newFc = new DtaStoreFacade();
	}

	@AfterEach
	void tearDown() throws Exception {
		newFc = null;
	}
	//Test Case Example
	//Test Case ID: Connect_DB_Unit_Test_Sunny_001
	//Test Purpose: Test if user can connect to DB
	//Setup: See Table 1 (User/Pw in DB)
	//Input: connectFacade("user1", "1234")
	//Expected Output: 0
	@Test
	public void testConnectFacade() {
		assertEquals(0, newFc.connectFacade("user1", "1234"));
	}
	//Input: Example
		//Sunny
		//input: newFc.disconnectFacade();
		//expected output: 0
		//Rainy
		//input: newFc.disconnectFacade();
		//expected output: -1
	@Test 
	public void testDisconnectFacade() {
		assertEquals(0, newFc.disconnectFacade());
	}
	//Input: Example
			//Sunny
			//input: newFc.fetchCourseIDFacade(4555);
			//expected output: 4555
			//Rainy
			//input: newFc.etchCourseIDFacade(3333);
			//expected output: -1
	@Test
	public void testFetchCourseIDFacade() {
		assertEquals(4555, newFc.fetchCourseIDFacade(4555));
	}
	//Input: Example
			//Sunny
			//input: [05001019, 05010019], newFc.getEndDatesFacade());
			//expected output: true
			//Rainy
			//input: [05001019, 05010010], newFc.getEndDatesFacade();
			//expected output: false
	@Test
	public void testGetEndDatesFacade() {
		ArrayList<String> temp = new ArrayList<>();
		temp.add("05001019");
		temp.add("05001019");
		temp.add("05010019");
		
		
		assertTrue(temp.equals(newFc.getEndDatesFacade()));
	}
	//Input: Example
			//Sunny
			//input: [4555, 4610], newFc.getCoursesFacade();
			//expected output: true
			//Rainy
			//input: [4555, 4611], newFc.getCoursesFacade();
			//expected output: false
	@Test
	public void testGetCoursesFacade() {
		ArrayList<Integer> temp = new ArrayList<>();
		temp.add(1101);
		temp.add(4555);
		temp.add(4610);
		
		
		assertTrue(temp.equals(newFc.getCoursesFacade()));
	}
	//Input: Example
			//Sunny
			//input:"COP", newFc.fetchCourseSubjFacade(4555);
			//expected output: "COP"
			//Rainy
			//input: "COP", newFc.fetchCourseSubjFacade(1101);
			//expected output: "COP"
	@Test
	public void testFetchCourseSubjFacade() {
		assertEquals("COP", newFc.fetchCourseSubjFacade(4555));
	}
	//Input: Example
			//Sunny
			//input:"OS", newFc.fetchCourseNameFacade(4610);
			//expected output: "OS"
			//Rainy
			//input: "COP", newFc.fetchCourseNameFacade(4610);
			//expected output: "COP"
	@Test
	public void testFetchCourseNameFacade() {
		assertEquals("OS", newFc.fetchCourseNameFacade(4610));
	}
	//Input: Example
			//Sunny
			//input:"OS", newFc.fetchCourseNameFacade(4610);
			//expected output: "OS"
			//Rainy
			//input: "COP", newFc.fetchCourseNameFacade(4610);
			//expected output: "COP"
	@Test
	public void testFetchCourseSemesterFacade() {
		assertEquals("Spring", newFc.fetchCourseSemesterFacade(4555));
	}
	@Test
	public void testFetchCourseStartFacade() {
		assertEquals("01008019", newFc.fetchCourseStartFacade(4555));
	}
	

}
