package PSM_Unit_Testing.DBConnection_Unit_testing;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class TestDBconnection {
	
	
	DBConnection myDB;
	Connection myCon;
	Statement statement;
	ResultSet result;
	
	@Before
	public void setUp() throws Exception {
		myDB = new DBConnection();
	}
	
	@After
	public void tearDown() throws Exception {
		myDB = null;
	}
	@Test
	public void testConnect() throws SQLException {
		myCon = mock(Connection.class);
		assertEquals(0, myDB.connect("user1", "1234", myCon));
	}
	@Test
	public void testDisconnect() throws SQLException {
		assertEquals(0, myDB.disconnect());
	}
	@Test
	public void testFetchCourseID() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getInt("course_id")).thenReturn(4555);
		myDB.setCon(myCon);
		assertEquals(4555, myDB.fetchCourseID(4555));
		verify(statement).executeQuery("SELECT course_id FROM class100 WHERE course_id = " + 4555 +";");
		verify(result).getInt("course_id");
	}
	@Test
	public void testGetEndDates() throws SQLException {
		ArrayList<String> state = new ArrayList<String>();
		state.add("05/01/19");
		state.add("05/01/19");
		state.add("05/01/19");
		
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, true, true, false);
		when(result.getString("end_date")).thenReturn("05/01/19", "05/01/19", "05/01/19");
		myDB.setCon(myCon);
		//System.out.println(myDB.getEndDates());
		assertEquals(state, myDB.getEndDates());
		verify(statement).executeQuery("SELECT end_date FROM class100");
		verify(result, times(3)).getString("end_date");
	}
	@Test
	public void testGetCourses() throws SQLException {
		ArrayList<Integer> state = new ArrayList<Integer>();
		state.add(1101);
		state.add(4555);
		state.add(4610);
		
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, true, true, false);
		when(result.getInt("course_id")).thenReturn(1101, 4555, 4610);
		myDB.setCon(myCon);
		//System.out.println(myDB.getCourses());
		assertEquals(state, myDB.getCourses());
		verify(statement).executeQuery("SELECT course_id FROM class100");
		verify(result, times(3)).getInt("course_id");
	}
	@Test
	public void testFechCourseSubj() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("course_subject")).thenReturn("English");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseSubj(1101));
		assertEquals("English", myDB.fetchCourseSubj(1101));
		verify(statement).executeQuery("SELECT course_subject FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("course_subject");
	}
	@Test
	public void testFetchCourseName() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("course_name")).thenReturn("ENC");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseName(1101));
		assertEquals("ENC", myDB.fetchCourseName(1101));
		verify(statement).executeQuery("SELECT course_name FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("course_name");
	}
	@Test
	public void testFetchCourseSemester() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("semester")).thenReturn("Spring");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseSemester(1101));
		assertEquals("Spring", myDB.fetchCourseSemester(1101));
		verify(statement).executeQuery("SELECT semester FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("semester");
	}
	@Test
	public void testFetchCourseStart() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_date")).thenReturn("01/08/19");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseStart(1101));
		assertEquals("01/08/19", myDB.fetchCourseStart(1101));
		verify(statement).executeQuery("SELECT start_date FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_date");
	}
	@Test
	public void testFetchCourseEnd() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_date")).thenReturn("05/01/19");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseEnd(1101));
		assertEquals("05/01/19", myDB.fetchCourseEnd(1101));
		verify(statement).executeQuery("SELECT end_date FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_date");
	}
	@Test
	public void testFetchStartMon() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_mon")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartMon(1101));
		assertEquals(null, myDB.fetchStartMon(1101));
		verify(statement).executeQuery("SELECT start_mon FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_mon");
	}
	@Test
	public void testFetchEndMon() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_mon")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartMon(1101));
		assertEquals(null, myDB.fetchEndMon(1101));
		verify(statement).executeQuery("SELECT end_mon FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_mon");
	}
	@Test
	public void testFetchStartTue() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_tue")).thenReturn("15:00");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartTue(1101));
		assertEquals("15:00", myDB.fetchStartTue(1101));
		verify(statement).executeQuery("SELECT start_tue FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_tue");
	}
	@Test
	public void testFetchEndTue() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_tue")).thenReturn("16:15");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStarttue(1101));
		assertEquals("16:15", myDB.fetchEndTue(1101));
		verify(statement).executeQuery("SELECT end_tue FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_tue");
	}
	@Test
	public void testFetchStartWed() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_wed")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartWed(1101));
		assertEquals(null, myDB.fetchStartWed(1101));
		verify(statement).executeQuery("SELECT start_wed FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_wed");
	}
	@Test
	public void testFetchEndWed() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_wed")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartWed(1101));
		assertEquals(null, myDB.fetchEndWed(1101));
		verify(statement).executeQuery("SELECT end_wed FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_wed");
	}
	@Test
	public void testFetchStartThu() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_thu")).thenReturn("15:00");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartThu(1101));
		assertEquals("15:00", myDB.fetchStartThu(1101));
		verify(statement).executeQuery("SELECT start_thu FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_thu");
	}
	@Test
	public void testFetchEndThu() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_thu")).thenReturn("16:15");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartThu(1101));
		assertEquals("16:15", myDB.fetchEndThu(1101));
		verify(statement).executeQuery("SELECT end_thu FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_thu");
	}
	@Test
	public void testFetchStartFri() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_fri")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartFri(1101));
		assertEquals(null, myDB.fetchStartFri(1101));
		verify(statement).executeQuery("SELECT start_fri FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_fri");
	}
	@Test
	public void testFetchEndFri() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_fri")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartFri(1101));
		assertEquals(null, myDB.fetchEndFri(1101));
		verify(statement).executeQuery("SELECT end_fri FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_fri");
	}
	@Test
	public void testFetchStartSat() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_sat")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartSat(1101));
		assertEquals(null, myDB.fetchStartSat(1101));
		verify(statement).executeQuery("SELECT start_sat FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_sat");
	}
	@Test
	public void testFetchEndSat() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_sat")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartSat(1101));
		assertEquals(null, myDB.fetchEndSat(1101));
		verify(statement).executeQuery("SELECT end_sat FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_sat");
	}
	@Test
	public void testStoreClassInfo() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenReturn(statement);
		myDB.setCon(myCon);
		assertEquals(0, myDB.storeClassInfo(1101, "ENC", "English", "Spring"));
		verify(statement).executeUpdate("INSERT INTO Class100 (course_id, course_subject, course_name, semester)" +
                " VALUES ( '"+ 1101 +"', '" + "ENC" +"', '" + "English" +"', '" + "Spring" +"')");
	}
	@Test
	public void testStoreClassSched() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenReturn(statement);
		myDB.setCon(myCon);
		assertEquals(0, myDB.storeClassSched(1101, "01/08/10", "05/01/19", null, null, "15:00", "16:15", null, null, "15:00", "16:15",
					 null, null, null, null));
		verify(statement).executeUpdate("UPDATE Class100 SET " +
                "start_date = '" + "01/08/10" +"', end_date = '" + "05/01/19" +"', start_mon =  '" 
                + null +"', end_mon = '" + null + "', start_tue = '" + "15:00" +"', end_tue = '" + "16:15" 
                +"', start_wed = '" + null +"', end_wed = '" + null +"', start_thu =  '" + "15:00" 
                + "', end_thu = '" + "16:15" +"', start_fri = '" + null +"', end_fri = '" + null 
                +"', start_sat =  '" + null +"', end_sat = '" + null
                +"' WHERE course_id = '" + 1101 + "';");
	}
	
}
