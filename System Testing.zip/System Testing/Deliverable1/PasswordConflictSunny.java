
import resources.PasswordConflictSunnyHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author syori
 */
public class PasswordConflictSunny extends PasswordConflictSunnyHelper
{
	/**
	 * Script Name   : <b>PasswordConflictSunny</b>
	 * Generated     : <b>Feb 21, 2019 8:56:17 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/21
	 * @author syori
	 */
	public void testMain(Object[] args) 
	{
		startApp("Deliverable1");

		
		// Frame: PSM Login
		username().click(atPoint(73,9));
		psmLogin().inputChars(dpString("user1"));
		password().click(atPoint(33,17));
		psmLogin().inputChars(dpString("pass1"));
		login().click();
		
		// Frame: System Message
		ok().click();
		
		// Frame: PSM Login
		psmLogin().inputChars(dpString("user2"));
		password().click(atPoint(46,6));
		psmLogin().inputChars(dpString("pass2"));
		login().click();
		
		// Frame: System Message
		ok().click();
		
		// Frame: PSM Login
		psmLogin().inputChars(dpString("user3"));
		password().click(atPoint(42,3));
		psmLogin().inputChars(dpString("pass3"));
		login().click();
		
		// Frame: System Message
		ok().click();
		systemMessage().performTest(SystemMessage_standardVP());
		ok2().click();
		
	}
}

