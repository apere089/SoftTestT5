
import resources.AddClass_RainyDayHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author syori
 */
public class AddClass_RainyDay extends AddClass_RainyDayHelper
{
	/**
	 * Script Name   : <b>AddClass_RainyDay</b>
	 * Generated     : <b>Feb 18, 2019 10:48:16 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/18
	 * @author syori
	 */
	public void testMain(Object[] args) 
	{
		
		startApp("Deliverable1");
		
		// Frame: PSM Login
		username().click(atPoint(28,7));
		psmLogin().inputChars("pclarke");
		password().click(atPoint(18,3));
		psmLogin().inputChars("1234");
		login().click();
		
		// Frame: PSM Main Menu
		addClassSchedule().click();
		
		
		// Frame: Schedule Setup
		jComboBox().click();
		jComboBox().click(atText("Fall"));
		startDate().click(atPoint(63,6));
		scheduleSetup().inputChars(dpString("startDate"));
		endDate().click(atPoint(25,0));
		scheduleSetup().inputChars(dpString("endDate"));
		subject().click(atPoint(10,4));
		scheduleSetup().inputChars(dpString("subject"));
		courseNumber().drag(atPoint(40,15), atPoint(40,14));
		scheduleSetup().inputChars(dpString("cNumber"));
		courseName().click(atPoint(187,5));
		scheduleSetup().inputChars(dpString("cName"));
		jTextField().click(atPoint(13,0));
		scheduleSetup().inputKeys(dpString("mS"));
		endTime().click(atPoint(27,6));
		scheduleSetup().inputKeys(dpString("mE"));
		tuesday().click(atPoint(39,9));
		scheduleSetup().inputKeys(dpString("tS"));
		monday().click(atPoint(40,4));
		scheduleSetup().inputKeys(dpString("tE"));
		wednesday().click(atPoint(24,9));
		scheduleSetup().inputKeys(dpString("wS"));
		jTextField2().click(atPoint(39,9));
		scheduleSetup().inputKeys(dpString("wE"));
		thursday().click(atPoint(32,4));
		scheduleSetup().inputKeys(dpString("thS"));
		scheduleSetup().click(atPoint(364,375));
		jTextField3().click(atPoint(37,9));
		scheduleSetup().inputChars(dpString("thE"));
		friday().click(atPoint(39,6));
		scheduleSetup().inputKeys(dpString("fS"));
		jTextField4().click(atPoint(41,15));
		scheduleSetup().inputChars(dpString("fE"));
		saturday().click(atPoint(36,8));
		scheduleSetup().inputChars(dpString("sS"));
		jTextField5().click(atPoint(30,12));
		scheduleSetup().inputKeys(dpString("sE"));
		save().click();
		scheduleSetup().performTest(ScheduleSetup_standardVP());
		cancel().click();
		
		sleep(10);
		//Must manually force quit the app since it freezes 
		
		
	}
}

