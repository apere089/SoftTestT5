
import resources.EditClassHelper;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author syori
 */
public class EditClass extends EditClassHelper
{
	/**
	 * Script Name   : <b>EditClassSunny</b>
	 * Generated     : <b>Feb 21, 2019 7:56:41 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/21
	 * @author syori
	 */
	public void testMain(Object[] args) 
	{
		 String localDb = "jdbc:mysql://localhost:3306/localdb";
		 Connection myCon = null;
		 try{
	            Class.forName("com.mysql.jdbc.Driver");
	            myCon = DriverManager.getConnection(localDb,"pclarke","1234");
	            Statement s = myCon.createStatement();
	            s.execute("DELETE FROM class100;");
	            s.execute("INSERT INTO class100 VALUES(" + 1101 + ",'ENC','English','Spring',"
	            		+ "'01/08/19','04/28/19',1500,1615 ,'00000','00000',1500,"
	            		+ "'1700','00000','00000','00000','00000','00000','00000');");
	            s.execute("INSERT INTO class100 VALUES(" + 4555 + ",'COP','Prog. Languages','Spring',"
	            		+ "'01/08/19','04/28/19','00000','00000',1500,1615,'00000',"
	            		+ "'00000',1500,1615,'00000','00000','00000','00000');");
	            s.execute("INSERT INTO class100 VALUES(" + 4610 + ",'COP','Op. Systems','Spring',"
	            		+ "'01/08/19','04/28/19','00000','00000',1745,1900,'00000',"
	            		+ "'00000',1745,1900,'00000','00000','00000','00000');");
	        } 
	        catch (Exception e){
	            e.printStackTrace();              // -1 = Fail State
	        }
		 
		 startApp("Deliverable1");
		
				
		// Frame: PSM Login
		username().click(atPoint(66,7));
		psmLogin().inputChars("pclarke");
		password().click(atPoint(21,16));
		psmLogin().inputChars("1234");
		login().click();
		
		// Frame: PSM Main Menu
		editSchedule().click();
		
		
		// Frame: Please Choose
		jComboBox().click();
		jComboBox().click(atText(dpString("cNumberOutput")));
		edit().click();
		
		
		
		// Frame: Edit Schedule
		jComboBox2().click();
		jComboBox2().click(atText(dpString("Semester")));
		startDate().click(atPoint(76,5));
		editSchedule2().inputKeys("^a{BKSP}" + dpString("startDate"));
		endDate().click(atPoint(61,12));
		editSchedule2().inputKeys("^a{BKSP}" + dpString("endDate"));
		subject().click(atPoint(30,0));
		editSchedule2().inputKeys("^a{BKSP}" + dpString("subject"));
		courseNumber().click(atPoint(44,8));
		editSchedule2().inputKeys("^a{BKSP}" + dpString("cNumber"));
		courseName().click(atPoint(207,6));
		editSchedule2().inputKeys("^a{BKSP}" + dpString("cName"));
		jTextField().click(atPoint(56,9));
		editSchedule2().inputKeys("^a{BKSP}" + dpString("mS"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("tS"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("wS"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("thS"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("fS"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("sS"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("mE"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("tE"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("wE"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("thE"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("fE"));
		editSchedule2().inputKeys("{TAB}");
		editSchedule2().inputKeys("^a{BKSP}" + dpString("sE"));
		save().click();
		
		
		
		// Frame: PSM Main Menu
		editSchedule().click();
		
		// Frame: Please Choose
		jComboBox().click();
		jComboBox().click(atText(dpString("cNumberOutput")));
		edit().click();
		

		startDate().performTest(StartDate_textVP());
		endDate().performTest(EndDate_textVP());
		subject().performTest(Subject_textVP());
		courseNumber().performTest(CourseNumber_textVP());
		courseName().performTest(CourseName_textVP());
		jTextField().performTest(sM_textVP());
		endTime().performTest(eM_textVP());
		tuesday().performTest(tS_textVP());
		monday().performTest(tE_textVP());
		wednesday().performTest(wS_textVP());
		jTextField2().performTest(wE_textVP());
		thursday().performTest(thS_textVP());
		jTextField3().performTest(thE_textVP());
		friday().performTest(fS_textVP());
		jTextField4().performTest(fE_textVP());
		saturday().performTest(sS_textVP());
		jTextField5().performTest(sE_textVP());
		
		
		
		// Frame: Edit Schedule
		save().click();
		
		// Frame: PSM Main Menu
		logout().click();
		
		// Frame: System Message
		ok(ANY,MAY_EXIT).drag();
		
}
}

