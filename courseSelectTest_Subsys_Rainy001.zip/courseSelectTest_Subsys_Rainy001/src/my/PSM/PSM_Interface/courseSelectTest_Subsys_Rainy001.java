package my.PSM.PSM_Interface;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import my.PSM.appController;

/* TestID: courseSelectTest_Subsys_Rainy001
 * 
 * Purpose: Verify that courseSelect is able to return a null 
 * when there are no courses to return.
 * 
 * Test Setup: In this setup nothing was mocked or changed.
 * 
 * Input: No input retrieving data from DBConnection.
 * 
 * Expected Output: null
 * 
 * 
 */

class courseSelectTest_Subsys_Rainy001 {

	private courseSelect test;
	
	@BeforeEach
	void setUp() throws Exception {
		test = new courseSelect();

	}

	@AfterEach
	void tearDown() throws Exception {
		test = null;

	}

	@Test
	void testCourseSelect() {
		assertEquals(null, appController.db.fetchCourses());
	    
	}

}
