
import resources.Login_SunnyDayHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author syori
 */
public class Login_SunnyDay extends Login_SunnyDayHelper
{
	/**
	 * Script Name   : <b>Login_SunnyDay</b>
	 * Generated     : <b>Feb 18, 2019 6:06:58 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/18
	 * @author syori
	 */
	public void testMain(Object[] args) 
	{
		
		startApp("Deliverable1");
		
		
		// Frame: PSM Login
		username().click(atPoint(32,3));
		psmLogin().inputChars("pclarke");
		password().click(atPoint(65,8));
		psmLogin().inputChars("1234");
		login().click();
		
		
		// Frame: PSM Main Menu
		psmMainMenu().performTest(PSMMainMenu_standardVP());
		
		sleep(2);
		// Frame: PSM Main Menu
		logout().click();
		
		// Frame: System Message
		ok(ANY,MAY_EXIT).click();	
		
		
		
	}
}

