
import resources.Script1Helper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author Samuel
 */
public class Script1 extends Script1Helper
{
	/**
	 * Script Name   : <b>Script1</b>
	 * Generated     : <b>Feb 18, 2019 2:51:40 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/18
	 * @author Samuel
	 */
	public void testMain(Object[] args) 
	{
		
		// Frame: PSM Main Menu
		addClassSchedule().click();
		logInfo("Add selected");
		// Frame: Schedule Setup
		jComboBox().click();
		jComboBox().click(atText("Select Semester"));
		scheduleSetup().dragToScreenPoint(atPoint(178,110), toScreenPoint(
                                        177, 113));
		jComboBox().click();
		jComboBox().click(atText("Fall"));
		startDate().click(atPoint(52,17));
		scheduleSetup().inputKeys(dpString("startDate"));
		endDate().click(atPoint(22,16));
		scheduleSetup().inputKeys(dpString("endDate"));
		subject().click(atPoint(14,4));
		scheduleSetup().inputKeys(dpString("subject"));
		courseNumber().click(atPoint(63,5));
		scheduleSetup().inputKeys(dpString("cNumber"));
		courseName().click(atPoint(196,17));
		scheduleSetup().inputChars(dpString("cName"));
		scheduleSetup().inputChars("s");
		jTextField().click(atPoint(44,15));
		scheduleSetup().inputKeys(dpString("monS"));
		endTime().click(atPoint(16,12));
		scheduleSetup().inputKeys(dpString("monE"));
		tuesday().drag(atPoint(52,18), atPoint(52,17));
		scheduleSetup().inputKeys(dpString("tueS"));
		monday().click(atPoint(54,5));
		scheduleSetup().inputKeys(dpString("tueE"));
		wednesday().click(atPoint(43,3));
		scheduleSetup().inputKeys(dpString("WS"));
		jTextField2().click(atPoint(44,8));
		scheduleSetup().inputKeys(dpString("WE"));
		thursday().click(atPoint(14,17));
		scheduleSetup().inputKeys(dpString("THS"));
		jTextField3().click(atPoint(31,16));
		scheduleSetup().inputKeys(dpString("THE"));
		friday().click(atPoint(8,16));
		scheduleSetup().inputKeys(dpString("FS"));
		jTextField4().click(atPoint(26,17));
		scheduleSetup().inputKeys(dpString("FE"));
		saturday().click(atPoint(20,11));
		scheduleSetup().inputKeys(dpString("SS"));
		jTextField5().click(atPoint(21,14));
		scheduleSetup().inputKeys(dpString("SE"));
		save().click();
		logInfo("Class information entered");
		
		// Frame: eclipse-workspace - PSM2/src/my/PSM/PSM_Storage/DBConnection.java - Eclipse IDE
		tree().click(atPoint(289,16));
		sleep(1);
		annotationRulerColumn4().click(atPoint(2,620));
		sleep(1);
		styledText().click(atPoint(233,558));
		sleep(1);
		// Document: Welcome to the Eclipse IDE for Java Developers: about:blank
		html_standby().click(atPoint(354,644));
		sleep(1);
		logInfo("Databases reinitialized");
		
		// Window: MySQLWorkbench.exe: Apply SQL Script to Database
		applybutton().click();
		applybutton().click();
	}
}

