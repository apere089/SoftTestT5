
import resources.AddClass_SunnyDayHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author syori
 */
public class AddClass_SunnyDay extends AddClass_SunnyDayHelper
{
	/**
	 * Script Name   : <b>AddClass_SunnyDay</b>
	 * Generated     : <b>Feb 18, 2019 7:29:36 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/18
	 * @author syori
	 */
	public void testMain(Object[] args) 
	{
		
		String localDb = "jdbc:mysql://localhost:3306/localdb";
		 Connection myCon = null;
		 try{
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            myCon = DriverManager.getConnection(localDb,"pclarke","1234");
	            Statement s = myCon.createStatement();
	            s.execute("DELETE FROM class100;");
	            s.execute("INSERT INTO class100 VALUES(" + 1101 + ",'ENC','English','Spring',"
	            		+ "'01/08/19','04/28/19',1500,1615 ,'00000','00000',1500,"
	            		+ "'1700','00000','00000','00000','00000','00000','00000');");
	            s.execute("INSERT INTO class100 VALUES(" + 4555 + ",'COP','Prog. Languages','Spring',"
	            		+ "'01/08/19','04/28/19','00000','00000',1500,1615,'00000',"
	            		+ "'00000',1500,1615,'00000','00000','00000','00000');");
	            s.execute("INSERT INTO class100 VALUES(" + 4610 + ",'COP','Op. Systems','Spring',"
	            		+ "'01/08/19','04/28/19','00000','00000',1745,1900,'00000',"
	            		+ "'00000',1745,1900,'00000','00000','00000','00000');");
	        } 
	        catch (Exception e){
	            e.printStackTrace();              // -1 = Fail State
	        }
		
		startApp("Deliverable1");
		
		
		// Window: javaw.exe: PSM Login
		psmLoginwindow().inputKeys("pclarke{TAB}");
		psmLoginwindow().inputChars("1234");
		psmLoginwindow().click(atPoint(148,169));
		
		
		// Frame: PSM Main Menu
		addClassSchedule().click();
		
		
		// Frame: Schedule Setup
		
		// Frame: Schedule Setup
		jComboBox2().click();
		jComboBox2().click(atText(dpString("Semester")));
		startDate2().click(atPoint(45,14));
		scheduleSetupwindow().inputKeys(dpString("startDate") + "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("endDate")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("subject")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("cNumber")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("cName")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("mS")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("tS")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("wS")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("thS")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("fS")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("sS")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("mE")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("tE")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("wE")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("thE")+ "{TAB}");
		scheduleSetupwindow().inputKeys(dpString("fE")+ "{TAB}");
		scheduleSetupwindow().inputChars(dpString("sE"));
		
		
		// Frame: Schedule Setup
		scheduleSetup().click(atPoint(432,398));
		save2().drag();
		

		// Frame: PSM Main Menu
		editSchedule().click();
		
				
		// Frame: Please Choose
		jComboBox().click();
		jComboBox().click(atText(dpString("cNumber")));
		edit().click();
		
		
		// Frame: Edit Schedule
		//Verification that class was added correctly
		startDate().performTest(StartDate_textVP());
		endDate().performTest(EndDate_textVP());
		subject().performTest(Subject_textVP());
		courseNumber().performTest(CourseNumber_textVP());
		courseName().performTest(CourseName_textVP());
		jTextField().performTest(mS_textVP());
		endTime().performTest(ME_textVP());
		tuesday().performTest(tS_textVP());
		monday().performTest(tE_textVP());		
		wednesday().performTest(wS_textVP());
		jTextField2().performTest(wE_selectedVP());
		thursday().performTest(thS_selectedVP());
		jTextField3().performTest(thE_textVP());
		friday().performTest(fS_textVP());
		jTextField4().performTest(fE_textVP());
		saturday().performTest(sS_textVP());
		jTextField5().performTest(sE_textVP());
		save().click();
		
		// Frame: PSM Main Menu
		logout().click();
		
		// Frame: System Message
		ok(ANY,MAY_EXIT).click();
		

		
		
		
	}
}

