
import resources.LoginRainyHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author syori
 */
public class LoginRainy extends LoginRainyHelper
{
	/**
	 * Script Name   : <b>LoginRainy</b>
	 * Generated     : <b>Feb 18, 2019 6:29:37 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/18
	 * @author syori
	 */
	public void testMain(Object[] args) 
	{
		
		
		startApp("Deliverable1");
		
		// Frame: PSM Login
		username().click(atPoint(54,12));
		psmLogin().inputChars(dpString("user"));
		password().click(atPoint(57,13));
		psmLogin().inputChars(dpString("pass"));
		login().click();
		
		// Frame: System Message
		ok().click();
		
		// Frame: PSM Login
		cancel(ANY,MAY_EXIT).click();
		
		
		
	}
}

