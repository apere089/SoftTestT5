
import resources.AddClass_RainyDayHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author syori
 */
public class AddClass_RainyDay extends AddClass_RainyDayHelper
{
	/**
	 * Script Name   : <b>AddClass_RainyDay</b>
	 * Generated     : <b>Feb 18, 2019 10:48:16 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/02/18
	 * @author syori
	 */
	public void testMain(Object[] args) 
	{
		
		startApp("Deliverable1");
		
		
		
		
		// Frame: PSM Login
		username().click(atPoint(35,11));
		psmLogin().inputChars("pclarke");
		password().click(atPoint(22,3));
		psmLogin().inputChars("1234");
		login().click();
		
		
		// Frame: PSM Main Menu
		addClassSchedule().click();
		
		// Frame: Schedule Setup
		jComboBox().click();
		jComboBox().click(atText("Fall"));
		startDate().click(atPoint(71,8));
		scheduleSetup().inputChars(dpString("startDate"));
		endDate().click(atPoint(15,2));
		scheduleSetup().inputChars(dpString("endDate"));
		subject().click(atPoint(6,4));
		scheduleSetup().inputChars(dpString("subject"));
		courseNumber().click(atPoint(79,7));
		scheduleSetup().inputChars(dpString("cNumber"));
		courseName().click(atPoint(173,8));
		scheduleSetup().inputChars(dpString("cName"));
		jTextField().click(atPoint(30,3));
		scheduleSetup().inputChars(dpString("mS"));
		tuesday().click(atPoint(42,8));
		scheduleSetup().inputChars(dpString("tS"));
		wednesday().click(atPoint(23,6));
		scheduleSetup().inputChars(dpString("wS"));
		thursday().click(atPoint(38,5));
		scheduleSetup().inputChars(dpString("thS"));
		friday().click(atPoint(18,3));
		scheduleSetup().inputChars(dpString("fS"));
		saturday().click(atPoint(20,6));
		scheduleSetup().inputChars(dpString("sS"));
		endTime().click(atPoint(14,13));
		scheduleSetup().inputChars(dpString("mE"));
		monday().click(atPoint(14,6));
		scheduleSetup().inputChars(dpString("tE"));
		jTextField2().click(atPoint(19,11));
		scheduleSetup().inputChars(dpString("wE"));
		jTextField3().click(atPoint(11,11));
		scheduleSetup().inputChars(dpString("thE"));
		jTextField4().click(atPoint(17,6));
		scheduleSetup().inputChars(dpString("fE"));
		jTextField5().click(atPoint(44,4));
		scheduleSetup().inputChars(dpString("sE"));
		
		// Frame: Schedule Setup
		scheduleSetup().close();
		
		// Frame: PSM Main Menu
		logout().click();
		sleep(10);
	}
}

