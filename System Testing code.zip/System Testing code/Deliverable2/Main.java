
import resources.MainHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;

import java.io.File;

import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author Samuel
 */
public class Main extends MainHelper
{
	/**
	 * Script Name   : <b>Main</b>
	 * Generated     : <b>Apr 15, 2019 8:30:15 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 17134 ()
	 * 
	 * @since  2019/04/15
	 * @author Samuel
	 */
	public void testMain(Object[] args) 
	{
		//String path = "C:\\\\Users\\Samuel\\IBM\\rationalsdp\\workspace\\Deliverable2\\Code\\PSM2\\cobertura.ser";
		
	//	File file = new File(path);
	//	file.delete();
		
		
		callScript("AddClass_SunnyDay");
		callScript("EditClass");
		callScript("Login_SunnyDay");
		callScript("LoginRainy");
		callScript("PasswordConflictSunny");
		callScript("AddClass_RainyDay");
	}
}

