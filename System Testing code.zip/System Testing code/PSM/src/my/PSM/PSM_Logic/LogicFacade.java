/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.PSM.PSM_Logic;


/**
 *
 * @author clarkep
 */
public class LogicFacade {
    
}
