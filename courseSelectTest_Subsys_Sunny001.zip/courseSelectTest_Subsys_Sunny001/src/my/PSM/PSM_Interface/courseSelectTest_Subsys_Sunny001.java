package my.PSM.PSM_Interface;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import my.PSM.PSM_Logic.appController;


/* TestID: courseSelectTest_Subsys_Sunny001
 * 
 * Purpose: This is a simple test to verify that courseSelect is able to successfully 
 * fetch a string that was hard coded into the return of the fecthCourses method of 
 * DBConnection. The appController is the class in the logic package that is responsible for 
 * retrieving it from DBConnection.
 * 
 * Test Setup: In this setup the return value was hard coded. 
 * 
 * Input: No input retrieving data from DBConnection.
 * 
 * Expected Output: Course Schedule CEN4072, CEN4010, COP4520, CAP4770
 * 
 * 
 */




class courseSelectTest_Subsys_Sunny001 {
	

	private courseSelect test; 
	@BeforeEach
	void setUp() throws Exception {
		test = new courseSelect();
	}

	@AfterEach
	void tearDown() throws Exception {
		test = null;
	}

	@Test
	void testCourseSelect() {
		
		assertEquals("CEN4072, CEN4010, COP4520, CAP4770", appController.db.fetchCourses());	
	}


}
