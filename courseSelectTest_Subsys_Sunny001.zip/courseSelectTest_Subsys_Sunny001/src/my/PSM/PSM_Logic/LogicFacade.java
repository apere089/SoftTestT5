/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.PSM.PSM_Logic;

import java.util.*;
import java.util.Date;
import java.sql.*;

import my.PSM.PSM_Storage.DBConnection;

/**
 *
 * @author clarkep
 */
public class LogicFacade {
	
	appController myCon = new appController();
	
	public LogicFacade() {
    	myCon.db = myCon.getDB();
    }
	//Facade for getData method
	public ArrayList<String> getDataFacade(int course) {
		
		ArrayList<String> courseData = new ArrayList<>();
		appController.getData(course);
		courseData.add(appController.defSub);
		courseData.add(appController.defSemester);
		courseData.add(appController.defCourseName);
		courseData.add(appController.defCourseStart);
		courseData.add(appController.defCourseEnd);
		courseData.add(appController.defMonStart);
		courseData.add(appController.defMonEnd);
		courseData.add(appController.defTueStart);
		courseData.add(appController.defTueEnd);
		courseData.add(appController.defWedStart);
		courseData.add(appController.defWedEnd);
		courseData.add(appController.defThuStart);
		courseData.add(appController.defThuEnd);
		courseData.add(appController.defFriStart);
		courseData.add(appController.defFriEnd);
		courseData.add(appController.defSatStart);
		courseData.add(appController.defSatEnd);
	
		
		return courseData;
	}
	//Facade for sleep method
	public long sleepFacade(int time) {
		long start = System.currentTimeMillis();
		long end;
		appController.sleep(time);
		end = System.currentTimeMillis();
		
		return end - start;
	}
	//Facade for setTime method
	public String setTimeFacade(int year, int month, int date, int hours, int mins) {
		myCon.setTime(year, month, date, hours, mins);
		return myCon.getTime().toString();
	}
	//Facade for getTime method
	public String getTimeFacade() {
		return myCon.getTime().toString();
	}
	//Facade for getTime method
	public Long getTimeInMillisFacade() {
		return appController.getTimeMillis();
	}
	//Facade for timerParser
	public String timerParser(String timer) {
		appController.timerParser(timer);
		String time = myCon.returnHr() + ":" + myCon.returnMin();
		return time;
	}
	//Facade return Hr/Min 
	public int returnHrFacade() {
		return myCon.returnHr();
	}
	public int returnMinFacade() {
		return myCon.returnMin();
	}
	//Facade for getEndTime
	public String getEndTimeFacade(int hrs, int mins) {
		String time = appController.getEndTime(hrs, mins).toString();
		return time;
	}
	//Facade for setSemesterClear
	public String setSemesterClearFacade(int year, int month, int date, int hrs, int mins) {
		appController.setSemesterClear(year, month, date, hrs, mins);
		return myCon.getSemesterClear().toString();
	}
	//Facade for getSemesterClear
	public String getSemesterClearFacade() {
		return myCon.getSemesterClear().toString();
	}
	//Facade for get15beforeEnd
	public String get15BeforeEndFacade(int hrs, int mins) {
		return appController.get15BeforeEnd(hrs, mins).toString();
	}
	//Facade for get5beforeEnd
	public String get5BeforeEndFacade(int hrs, int mins) {
		return appController.get5BeforeEnd(hrs, mins).toString();
	}
	/*
	public void start() {
		if(!myCon.getLoginStatus()) {
			System.out.println("not logged in");
		}
		myCon.db = myCon.getDB();//new DBConnection();
		//appController.LogIn();
		if(myCon.getLoginStatus()) {
			System.out.println("logged in");
		}

		// Test the getData() method using specific course ID
		appController.getData(4555);
		
		//Test the sleep() method using 10 secs
		//System.out.println("Start sleep");
		//appController.sleep(10000);
		//System.out.println("End sleep");
		
		
		//Testing setTime
		myCon.setTime(2019,1,14,10,30);
		//Testing getTime
		System.out.println(myCon.getTime());
		
		
		//gettimemillis
		System.out.println(appController.getTimeMillis());
		
		
		//timerparser test
		appController.timerParser(myCon.defMonEnd);
		//return hour/min tests
		System.out.println(myCon.returnHr());
		System.out.println(myCon.returnMin());
		
		
		//getEndTime test
		System.out.println(appController.getEndTime(10, 30));
		//setSemesterClear
		appController.setSemesterClear(2019, 1, 14, 12, 30);
		//getSemesterClear
		System.out.println(myCon.getSemesterClear());
		
		//get15MinsBeforeEnd
		System.out.println(appController.get15BeforeEnd(10, 30));
		//get5MinsBeforeend
		System.out.println(appController.get5BeforeEnd(10, 30));
		
	}
	*/
	public static void main(String[] args) {
		LogicFacade test = new LogicFacade();
		
		
		
	}
}


