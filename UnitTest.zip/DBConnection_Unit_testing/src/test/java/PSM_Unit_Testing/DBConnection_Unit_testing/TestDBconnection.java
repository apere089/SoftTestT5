package PSM_Unit_Testing.DBConnection_Unit_testing;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class TestDBconnection {
	
	
	DBConnection myDB;
	Connection myCon;
	Statement statement;
	ResultSet result;
	
	@Before
	public void setUp() throws Exception {
		myDB = new DBConnection();
	}
	
	@After
	public void tearDown() throws Exception {
		myDB = null;
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_Connect3Param_Sunny_01
	//Purpose: Test connect method that takes 3 params
	//Setup: connect receives a mocked connection
	//Input: Mocked connection
	//Expected Output: 0
	@Test
	public void testConnect3ParamSunny() throws SQLException {
		myCon = mock(Connection.class);
		assertEquals(0, myDB.connect("myCon", "user1", "1234", myCon));
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_Connect3Param_Rainy_01
	//Purpose: Test connect method that takes 3 params
	//Setup: connect receives a mocked connection
	//Input: Mocked connection
	//Expected Output: 0
	@Test
	public void testConnect3ParamRainy() throws SQLException {
		myCon = mock(Connection.class);
		assertEquals(0, myDB.connect("myCon", "user1", "1234", myCon));
	}
 	//Test ID: PSM_Unit_Test_DBConnect_Test_Connect_Sunny_01
	//Purpose: Test the connect method
	//Setup: connect receives a mocked connection
	//Input: Mocked connection
	//Expected Output: 0
	@Test
	public void testConnectSunny() throws SQLException {
		myCon = mock(Connection.class);
		assertEquals(0, myDB.connect("user1", "1234", myCon));
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_Connect_Rainy_01
	//Purpose: Test the connect method
	//Setup: connect receives a mocked connection
	//Input: Mocked connection
	//Expected Output: 0
	@Test
	public void testConnectRainy() throws SQLException {
		myCon = null;
		assertEquals(0, myDB.connect("user1", "1234", myCon));
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_Disconnect_Sunny_01
	//Purpose: Test the disconnect method
	//Setup: Mock db is connected
	//Input: Mocked connection
	//Expected Output: 0
	@Test
	public void testDisconnectSunny() throws SQLException {
		myCon = mock(Connection.class);
		myDB.setCon(myCon);
		assertEquals(0, myDB.disconnect());
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_Disconnect_Rainy_01
	//Purpose: Test the disconnect method
	//Setup: Mock db is connected
	//Input: Mocked connection
	//Expected Output: 0
	@Test
	public void testDisconnectRainy() throws SQLException {
		myDB.setCon(null);
		assertEquals(0, myDB.disconnect());
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_FetchCourses_Sunny_01
	//Purpose: Test the fetchCourses method
	//Setup: See table 1
	//Input: 4555
	//Expected Output: "4555,"
	@Test
	public void testFetchCoursesSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, false);
		when(result.getInt("course_id")).thenReturn(4555);
		myDB.setCon(myCon);
		String res = "4555,";
		assertTrue(res.equals(myDB.fetchCourses()));
		verify(statement).executeQuery("SELECT course_id FROM class100;" );
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_FetchCourses_Rainy_01
	//Purpose: Test the fetchCourses method
	//Setup: See table 1
	//Input: 4555
	//Expected Output: "1111,"
	@Test
	public void testFetchCoursesRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, false);
		when(result.getInt("course_id")).thenReturn(4555);
		myDB.setCon(myCon);
		String res = "1111,";
		assertFalse(res.equals(myDB.fetchCourses()));
		verify(statement).executeQuery("SELECT course_id FROM class100;" );
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseID_Sunny_01
	//Purpose: Test the fetchCourseID Method
	//Setup: See table 1
	//Input: 4555
	//Expected Output: true
	@Test
	public void testFetchCourseIDSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getInt("course_id")).thenReturn(4555);
		myDB.setCon(myCon);
		assertEquals(4555, myDB.fetchCourseID(4555));
		verify(statement).executeQuery("SELECT course_id FROM class100 WHERE course_id = " + 4555 +";");
		verify(result).getInt("course_id");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseID_Rainy_01
	//Purpose: Test the fetchCourseID Method
	//Setup: See table 1
	//Input: 3444
	//Expected Output: true
	@Test
	public void testFetchCourseIDRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getInt("course_id")).thenReturn(3444);
		myDB.setCon(myCon);
		assertTrue(4555 != myDB.fetchCourseID(3444));
		verify(statement).executeQuery("SELECT course_id FROM class100 WHERE course_id = " + 3444 +";");
		verify(result).getInt("course_id");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_getEndDates_Sunny_01
	//Purpose: Test the getEndsDates Method
	//Setup: See table 1
	//Input: arraylist with: ["05/01/19", 05/01/19", 05/01/19"]
	//Expected Output: true
	@Test
	public void testGetEndDatesSunny() throws SQLException {
		ArrayList<String> state = new ArrayList<String>();
		state.add("05/01/19");
		state.add("05/01/19");
		state.add("05/01/19");
		
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, true, true, false);
		when(result.getString("end_date")).thenReturn("05/01/19", "05/01/19", "05/01/19");
		myDB.setCon(myCon);
		//System.out.println(myDB.getEndDates());
		assertEquals(state, myDB.getEndDates());
		verify(statement).executeQuery("SELECT end_date FROM class100");
		verify(result, times(3)).getString("end_date");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_getEndDates_Rainy_01
	//Purpose: Test the getEndsDates Method
	//Setup: See table 1
	//Input: arraylist with: ["05/06/19", 05/02/19", 05/20/19"]
	//Expected Output: false
	@Test
	public void testGetEndDatesRainy() throws SQLException {
		ArrayList<String> state = new ArrayList<String>();
		state.add("05/01/19");
		state.add("05/01/19");
		state.add("05/01/19");
		
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, true, true, false);
		when(result.getString("end_date")).thenReturn("05/06/19", "05/02/19", "05/20/19");
		myDB.setCon(myCon);
		//System.out.println(myDB.getEndDates());
		assertFalse(state.equals(myDB.getEndDates()));
		verify(statement).executeQuery("SELECT end_date FROM class100");
		verify(result, times(3)).getString("end_date");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_getCourses_Sunny_01
	//Purpose: Test the getCourses Method
	//Setup: See table 1
	//Input: arraylist with: [1101, 4555, 4610]
	//Expected Output: true
	@Test
	public void testGetCoursesSunny() throws SQLException {
		ArrayList<Integer> state = new ArrayList<Integer>();
		state.add(1101);
		state.add(4555);
		state.add(4610);
		
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, true, true, false);
		when(result.getInt("course_id")).thenReturn(1101, 4555, 4610);
		myDB.setCon(myCon);
		//System.out.println(myDB.getCourses());
		assertEquals(state, myDB.getCourses());
		verify(statement).executeQuery("SELECT course_id FROM class100");
		verify(result, times(3)).getInt("course_id");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_getCourses_Rainy_01
	//Purpose: Test the getCourses Method
	//Setup: See table 1
	//Input: arraylist with: [1100, 4500, 4600]
	//Expected Output: false
	@Test
	public void testGetCoursesRainy() throws SQLException {
		ArrayList<Integer> state = new ArrayList<Integer>();
		state.add(1101);
		state.add(4555);
		state.add(4610);
		
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.next()).thenReturn(true, true, true, false);
		when(result.getInt("course_id")).thenReturn(1100, 4500, 4600);
		myDB.setCon(myCon);
		//System.out.println(myDB.getCourses());
		assertFalse(state.equals(myDB.getCourses()));
		verify(statement).executeQuery("SELECT course_id FROM class100");
		verify(result, times(3)).getInt("course_id");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseSubj_Sunny_01
	//Purpose: Test the fetchCourseSubj Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "English"
	@Test
	public void testFechCourseSubjSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("course_subject")).thenReturn("English");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseSubj(1101));
		assertEquals("English", myDB.fetchCourseSubj(1101));
		verify(statement).executeQuery("SELECT course_subject FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("course_subject");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseSubj_Rainy_01
	//Purpose: Test the fetchCourseSubj Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFechCourseSubjRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("course_subject")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseSubj(1101));
		assertEquals("Not Found", myDB.fetchCourseSubj(2000));
		verify(statement).executeQuery("SELECT course_subject FROM class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("course_subject");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseName_Sunny_01
	//Purpose: Test the fetchCourseName Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "ENC"
	@Test
	public void testFetchCourseNameSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("course_name")).thenReturn("ENC");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseName(1101));
		assertEquals("ENC", myDB.fetchCourseName(1101));
		verify(statement).executeQuery("SELECT course_name FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("course_name");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseName_Rainy_01
	//Purpose: Test the fetchCourseName Method
	//Setup: See table 1
	//Input: 2000 
	//Expected Output: "Not Found"
	@Test
	public void testFetchCourseNameRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("course_name")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseName(1101));
		assertEquals("Not Found", myDB.fetchCourseName(2000));
		verify(statement).executeQuery("SELECT course_name FROM class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("course_name");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseSemester_Sunny_01
	//Purpose: Test the fetchCourseSemester Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "Spring"
	@Test
	public void testFetchCourseSemesterSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("semester")).thenReturn("Spring");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseSemester(1101));
		assertEquals("Spring", myDB.fetchCourseSemester(1101));
		verify(statement).executeQuery("SELECT semester FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("semester");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseSemester_Rainy_01
	//Purpose: Test the fetchCourseSemester Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "SNot Found"
	@Test
	public void testFetchCourseSemesterRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("semester")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseSemester(1101));
		assertEquals("Not Found", myDB.fetchCourseSemester(2000));
		verify(statement).executeQuery("SELECT semester FROM class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("semester");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseStart_Sunny_01
	//Purpose: Test the fetchCourseStart Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "01/08/19"
	@Test
	public void testFetchCourseStartSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_date")).thenReturn("01/08/19");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseStart(1101));
		assertEquals("01/08/19", myDB.fetchCourseStart(1101));
		verify(statement).executeQuery("SELECT start_date FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_date");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseStart_Rainy_01
	//Purpose: Test the fetchCourseStart Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchCourseStartRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_date")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseStart(1101));
		assertEquals("Not Found", myDB.fetchCourseStart(2000));
		verify(statement).executeQuery("SELECT start_date FROM class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("start_date");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseEnd_Sunny_01
	//Purpose: Test the fetchCourseEnd Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "05/01/19"
	@Test
	public void testFetchCourseEndSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_date")).thenReturn("05/01/19");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseEnd(1101));
		assertEquals("05/01/19", myDB.fetchCourseEnd(1101));
		verify(statement).executeQuery("SELECT end_date FROM class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_date");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchCourseEnd_Rainy_01
	//Purpose: Test the fetchCourseEnd Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchCourseEndRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_date")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchCourseEnd(1101));
		assertEquals("Not Found", myDB.fetchCourseEnd(2000));
		verify(statement).executeQuery("SELECT end_date FROM class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("end_date");
	}
	@Test
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartMon_Sunny_01
	//Purpose: Test the fetchStartMon Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "null"
	public void testFetchStartMonSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_mon")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartMon(1101));
		assertEquals(null, myDB.fetchStartMon(1101));
		verify(statement).executeQuery("SELECT start_mon FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_mon");
	}
	@Test
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartMon_Rainy_01
	//Purpose: Test the fetchStartMon Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	public void testFetchStartMonRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_mon")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartMon(1101));
		assertEquals("Not Found", myDB.fetchStartMon(2000));
		verify(statement).executeQuery("SELECT start_mon FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("start_mon");
	}
	@Test
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndMon_Sunny_01
	//Purpose: Test the fetchEndMon Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "null"
	public void testFetchEndMonSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_mon")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartMon(1101));
		assertEquals(null, myDB.fetchEndMon(1101));
		verify(statement).executeQuery("SELECT end_mon FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_mon");
	}
	@Test
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndMon_Rainy_01
	//Purpose: Test the fetchEndMon Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	public void testFetchEndMonRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_mon")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartMon(1101));
		assertEquals("Not Found", myDB.fetchEndMon(2000));
		verify(statement).executeQuery("SELECT end_mon FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("end_mon");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartTue_Sunny_01
	//Purpose: Test the fetchStartTue Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "15:00"
	@Test
	public void testFetchStartTueSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_tue")).thenReturn("15:00");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartTue(1101));
		assertEquals("15:00", myDB.fetchStartTue(1101));
		verify(statement).executeQuery("SELECT start_tue FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_tue");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartTue_Rainy_01
	//Purpose: Test the fetchStartTue Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchStartTueRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_tue")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartTue(1101));
		assertEquals("Not Found", myDB.fetchStartTue(2000));
		verify(statement).executeQuery("SELECT start_tue FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("start_tue");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndTue_Sunny_01
	//Purpose: Test the fetchendTue Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "16:15"
	@Test
	public void testFetchEndTueSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_tue")).thenReturn("16:15");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStarttue(1101));
		assertEquals("16:15", myDB.fetchEndTue(1101));
		verify(statement).executeQuery("SELECT end_tue FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_tue");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndTue_Rainy_01
	//Purpose: Test the fetchendTue Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchEndTueRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_tue")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStarttue(1101));
		assertEquals("Not Found", myDB.fetchEndTue(2000));
		verify(statement).executeQuery("SELECT end_tue FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("end_tue");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartWed_Sunny_01
	//Purpose: Test the fetchStartWed Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: null
	@Test
	public void testFetchStartWedSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_wed")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartWed(1101));
		assertEquals(null, myDB.fetchStartWed(1101));
		verify(statement).executeQuery("SELECT start_wed FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_wed");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartWed_Rainy_01
	//Purpose: Test the fetchStartWed Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchStartWedRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_wed")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartWed(1101));
		assertEquals("Not Found", myDB.fetchStartWed(2000));
		verify(statement).executeQuery("SELECT start_wed FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("start_wed");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndWed_Sunny_01
	//Purpose: Test the fetchEndWed Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: null
	@Test
	public void testFetchEndWedSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_wed")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartWed(1101));
		assertEquals(null, myDB.fetchEndWed(1101));
		verify(statement).executeQuery("SELECT end_wed FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_wed");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndWed_Rainy_01
	//Purpose: Test the fetchEndWed Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchEndWedRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_wed")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartWed(1101));
		assertEquals("Not Found", myDB.fetchEndWed(2000));
		verify(statement).executeQuery("SELECT end_wed FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("end_wed");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartThu_Sunny_01
	//Purpose: Test the fetchStartThu Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "15:00"
	@Test
	public void testFetchStartThuSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_thu")).thenReturn("15:00");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartThu(1101));
		assertEquals("15:00", myDB.fetchStartThu(1101));
		verify(statement).executeQuery("SELECT start_thu FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_thu");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartThu_Rainy_01
	//Purpose: Test the fetchStartThu Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found
	@Test
	public void testFetchStartThuRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_thu")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartThu(1101));
		assertEquals("Not Found", myDB.fetchStartThu(2000));
		verify(statement).executeQuery("SELECT start_thu FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("start_thu");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndThu_Sunny_01
	//Purpose: Test the fetchStartThu Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: "16:15"
	@Test
	public void testFetchEndThuSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_thu")).thenReturn("16:15");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartThu(1101));
		assertEquals("16:15", myDB.fetchEndThu(1101));
		verify(statement).executeQuery("SELECT end_thu FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_thu");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndThu_Rainy_01
	//Purpose: Test the fetchEndThu Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchEndThuRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_thu")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartThu(1101));
		assertEquals("Not Found", myDB.fetchEndThu(2000));
		verify(statement).executeQuery("SELECT end_thu FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("end_thu");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchSartFri_Sunny_01
	//Purpose: Test the fetchStartFri Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: null
	@Test
	public void testFetchStartFriSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_fri")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartFri(1101));
		assertEquals(null, myDB.fetchStartFri(1101));
		verify(statement).executeQuery("SELECT start_fri FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_fri");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchSartFri_Rainy_01
	//Purpose: Test the fetchStartFri Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchStartFriRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_fri")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartFri(1101));
		assertEquals("Not Found", myDB.fetchStartFri(2000));
		verify(statement).executeQuery("SELECT start_fri FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("start_fri");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndFri_Sunny_01
	//Purpose: Test the fetchEndFri Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: null
	@Test
	public void testFetchEndFriSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_fri")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartFri(1101));
		assertEquals(null, myDB.fetchEndFri(1101));
		verify(statement).executeQuery("SELECT end_fri FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_fri");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndFri_Rainy_01
	//Purpose: Test the fetchEndFri Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchEndFriRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_fri")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartFri(1101));
		assertEquals("Not Found", myDB.fetchEndFri(2000));
		verify(statement).executeQuery("SELECT end_fri FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("end_fri");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartSat_Sunny_01
	//Purpose: Test the fetchStartSat Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: null
	@Test
	public void testFetchStartSatSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_sat")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartSat(1101));
		assertEquals(null, myDB.fetchStartSat(1101));
		verify(statement).executeQuery("SELECT start_sat FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("start_sat");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchStartSat_Rainy_01
	//Purpose: Test the fetchStartSat Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchStartSatRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("start_sat")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartSat(1101));
		assertEquals("Not Found", myDB.fetchStartSat(2000));
		verify(statement).executeQuery("SELECT start_sat FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("start_sat");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndSat_Rainy_01
	//Purpose: Test the fetchEndSat Method
	//Setup: See table 1
	//Input: 1101
	//Expected Output: null
	@Test
	public void testFetchEndSatSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_sat")).thenReturn(null);
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartSat(1101));
		assertEquals(null, myDB.fetchEndSat(1101));
		verify(statement).executeQuery("SELECT end_sat FROM Class100 WHERE course_id = " + 1101 +";");
		verify(result).getString("end_sat");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_fetchEndSat_Rainy_01
	//Purpose: Test the fetchEndSat Method
	//Setup: See table 1
	//Input: 2000
	//Expected Output: "Not Found"
	@Test
	public void testFetchEndSatRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		result = mock(ResultSet.class);
		when(myCon.createStatement()).thenReturn(statement);
		when(statement.getResultSet()).thenReturn(result);
		when(result.getString("end_sat")).thenReturn("Not Found");
		myDB.setCon(myCon);
		//System.out.println(myDB.fetchStartSat(1101));
		assertEquals("Not Found", myDB.fetchEndSat(2000));
		verify(statement).executeQuery("SELECT end_sat FROM Class100 WHERE course_id = " + 2000 +";");
		verify(result).getString("end_sat");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_storeClassInfo_Sunny_01
	//Purpose: Test the fstoreClassInfo Method
	//Setup: See table 1
	//Input: course_id = 1101, ccourse_subject = "ENC", course_name = "English", semester = "Spring"
	//Expected Output: 0
	@Test
	public void testStoreClassInfoSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenReturn(statement);
		myDB.setCon(myCon);
		assertEquals(0, myDB.storeClassInfo(1101, "ENC", "English", "Spring"));
		verify(statement).executeUpdate("INSERT INTO Class100 (course_id, course_subject, course_name, semester)" +
                " VALUES ( '"+ 1101 +"', '" + "ENC" +"', '" + "English" +"', '" + "Spring" +"')");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_storeClassInfo_Sunny_01
	//Purpose: Test the fstoreClassInfo Method
	//Setup: See table 1
	//Input: course_id = 1101, ccourse_subject = "ENC", course_name = "English", semester = "Spring"
	//Expected Output: 0
	@Test
	public void testStoreClassInfoRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenReturn(statement);
		myDB.setCon(myCon);
		assertEquals(0, myDB.storeClassInfo(1101, "ENC", "English", "Spring"));
		verify(statement).executeUpdate("INSERT INTO Class100 (course_id, course_subject, course_name, semester)" +
	                " VALUES ( '"+ 1101 +"', '" + "ENC" +"', '" + "English" +"', '" + "Spring" +"')");
	}
	//Test ID: PSM_Unit_Test_DBConnect_Test_storeClassSched_Sunny_01
	//Purpose: Test the storeClassSched Method
	//Setup: See table 1
	//Input: course_id = 1101, start_mon = "01/08/10", end_mon = "05/01/19", start_tue = null, end_tue = null, start_wed = "15:00", 
	// end_wed = "16:15", start_thu = null, end_thu = null, start_sat = "15:00", end_sat = "16:15"
	//Expected Output: 0
	@Test
	public void testStoreClassSchedSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenReturn(statement);
		myDB.setCon(myCon);
		assertEquals(0, myDB.storeClassSched(1101, "01/08/10", "05/01/19", null, null, "15:00", "16:15", null, null, "15:00", "16:15",
					 null, null, null, null));
		verify(statement).executeUpdate("UPDATE Class100 SET " +
                "start_date = '" + "01/08/10" +"', end_date = '" + "05/01/19" +"', start_mon =  '" 
                + null +"', end_mon = '" + null + "', start_tue = '" + "15:00" +"', end_tue = '" + "16:15" 
                +"', start_wed = '" + null +"', end_wed = '" + null +"', start_thu =  '" + "15:00" 
                + "', end_thu = '" + "16:15" +"', start_fri = '" + null +"', end_fri = '" + null 
                +"', start_sat =  '" + null +"', end_sat = '" + null
                +"' WHERE course_id = '" + 1101 + "';");
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_storeClassSched_Rainy_01
	//Purpose: Test the storeClassSched Method
	//Setup: See table 1
	//Input: course_id = 1101, start_mon = "01/08/10", end_mon = "05/01/19", start_tue = null, end_tue = null, start_wed = "15:00", 
	// end_wed = "16:15", start_thu = null, end_thu = null, start_sat = "15:00", end_sat = "16:15"
	//Expected Output: 0
	@Test(expected = Exception.class)
	public void testStoreClassSchedRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenThrow(Exception.class);
		myDB.setCon(myCon);
		assertEquals(-1, myDB.storeClassSched(1101, "01/08/10", "05/01/19", null, null, "15:00", "16:15", null, null, "15:00", "16:15",
				 null, null, null, null));
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_clearDatabase_Sunny_01
	//Purpose: Test the clearDatabase Method
	//Setup: See table 1
	//Input: void
	//Expected Output: verify statement
	@Test
	public void testClearDatabaseSunny() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenReturn(statement);
		myDB.setCon(myCon);
		myDB.clearDatabase();
		verify(statement).execute("DELETE FROM class100;");
	}
	//******************NEW TEST CASE******************
	//******************ADD TO DELIVERABLE 2***********
	//Test ID: PSM_Unit_Test_DBConnect_Test_clearDatabase_Sunny_01
	//Purpose: Test the clearDatabase Method
	//Setup: See table 1
	//Input: void
	//Expected Output: verify statement
	@Test(expected = Exception.class)
	public void testClearDatabaseRainy() throws SQLException {
		statement = mock(Statement.class);
		myCon = mock(Connection.class);
		when(myCon.createStatement()).thenThrow(Exception.class);
		myDB.setCon(myCon);
		myDB.clearDatabase();
		verify(statement).execute("DELETE FROM class100;");
	}
	@Test
	public void testTestDBSunny() throws SQLException {
		myCon = mock(Connection.class);
		myDB.setCon(myCon);
		assertTrue(myDB.testDB(5));
	}
	@Test
	public void testTestDBRainy() throws SQLException {
		myCon = mock(Connection.class);
		myDB.setCon(myCon);
		assertFalse(myDB.testDB(0));
	}
}
