package PSM_Unit_Testing.appController_Unit_Test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import my.PSM.PSM_Interface.LoginForm;
import my.PSM.PSM_Interface.Messages;
import my.PSM.PSM_Logic.Authenticate;
import my.PSM.PSM_Logic.InterfaceController;
import my.PSM.PSM_Storage.DBConnection;

public class testAppController {

	@Mock
	Connection connection;
	@Mock
	Statement statement;
	@Mock
	DBConnection dbCon;
	@Mock
	InterfaceController icMock;
	@Mock
	Authenticate authMock;
	@Mock
	LoginForm logMock;
	@Mock
	Messages msgMock;
 
	
	appController controller;
	
	@Before
	public void setUp() throws Exception {
		controller = new appController();
		
		dbCon = mock(DBConnection.class);
		statement = mock(Statement.class);
		connection = mock(Connection.class);
		authMock = mock(Authenticate.class);
		icMock = mock(InterfaceController.class);
		logMock = mock(LoginForm.class);
		msgMock = mock(Messages.class);
		
		controller.setDB(dbCon);
		controller.setAuthenticate(authMock);
		controller.setInterfaceController(icMock);
	}

	@After
	public void tearDown() throws Exception {
		controller = null;
	}
	//Test ID: PSM_Unit_Test_CheckClear_Sunny_01
	//Purpose: Test CheckClear method
	//Test setup: See Table 1
	//Input: "01/08/19", "01/08/19", "01/08/19"
	//Expected output: True since the dates are before today (01/08/19)
	@Test
	public void testCheckClearSunny() {
		// Table 1
		ArrayList<String> date = new ArrayList<String>();
		date.add("01/08/19");
		date.add("01/08/19");
		date.add("01/08/19");
		
		when(dbCon.getEndDates()).thenReturn(date);
		assertTrue(controller.checkClear());
		verify(dbCon).getEndDates();
	}
	
	//Test ID: PSM_Unit_Test_CheckClear_Rainy_01
	//Purpose: Test CheckClear method
	//Test Setup: See Table 1
	//Input: "03/08/19", "03/08/19", "03/08/19"
	//Expected output: False since the dates are after today's date (03/08/19)
	@Test
	public void testCheckClearRainy() {
		// Table 1
		ArrayList<String> date = new ArrayList<String>();
		date.add("03/08/19");
		date.add("03/08/19");
		date.add("03/08/19");
		
		when(dbCon.getEndDates()).thenReturn(date);
		assertFalse(controller.checkClear());
		verify(dbCon).getEndDates();
	}
	
	//Test ID: PSM_Unit_Test_CheckTimes_Sunny_01
	//Purpose: Test CheckTimes method
	//Test Setup: See Table 1
	//Input: date.add(1101), defSub = "ENC", defSemester = "Spring", defCourseName = "English",
    //defCourseStart = "01/08/19", defCourseEnd = "05/01/19", defMonStart = "15:00", defMonEnd = "16:00", defTueStart = "15:00",
    //defTueEnd = "16:00", defWedStart = "15:00", defWedEnd = "16:00", defThuStart = "15:00", defThuEnd = "16:00",
    //defFriStart = "15:00", defFriEnd = "16:00", defSatStart = "15:00", defSatEnd = "16:00"
	//Expected Output: False because isNull (the return value of CheckTimes) will be False, since we set times for each day in the input
	
	@Test
	public void testCheckTimesSunny() {
		
		// Table 1
		ArrayList<Integer> date = new ArrayList<Integer>();
		date.add(1101);
		String defSub = "ENC";
        String defSemester = "Spring";
        String defCourseName = "English";
        String defCourseStart = "01/08/19";
        String defCourseEnd = "05/01/19";
        String defMonStart = "15:00";
        String defMonEnd = "16:00";
        String defTueStart = "15:00";
        String defTueEnd = "16:00";
        String defWedStart = "15:00";
        String defWedEnd = "16:00";
        String defThuStart = "15:00";
        String defThuEnd = "16:00";
        String defFriStart = "15:00";
        String defFriEnd = "16:00";
        String defSatStart = "15:00";
        String defSatEnd = "16:00";
        
		when(dbCon.getCourses()).thenReturn(date);
		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);
		
		assertFalse(controller.checkTimes());
	}
	
	//Test ID: PSM_Unit_Test_CheckTimes_Rainy_01
	//Purpose: Test CheckTimes method
	//Test Setup: See Table 1
	//Input: date.add(1101), defSub = "", defSemester = "", defCourseName = "",
	//defCourseStart = "", defCourseEnd = "", defMonStart = "", defMonEnd = "", defTueStart = "",
	//defTueEnd = "", defWedStart = "", defWedEnd = "", defThuStart = "", defThuEnd = "",
	//defFriStart = "", defFriEnd = "", defSatStart = "", defSatEnd = ""
	//Expected Output: True because isNull (the return value of CheckTimes) will be True, since we set the times to empty strings
		
	@Test
	public void testCheckTimesRainy() {
			
		// Table 1
		ArrayList<Integer> date = new ArrayList<Integer>();
		date.add(1101);
		String defSub = "";
	    String defSemester = "";
	    String defCourseName = "";
	    String defCourseStart = "";
	    String defCourseEnd = "";
	    String defMonStart = "";
	    String defMonEnd = "";
	    String defTueStart = "";
	    String defTueEnd = "";
	    String defWedStart = "";
	    String defWedEnd = "";
	    String defThuStart = "";
	    String defThuEnd = "";
	    String defFriStart = "";
	    String defFriEnd = "";
	    String defSatStart = "";
	    String defSatEnd = "";
	        
		when(dbCon.getCourses()).thenReturn(date);
		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);
			
		assertTrue(controller.checkTimes());
	}
	
	//Test ID: PSM_Unit_Test_getData_Sunny_01
	//Purpose: Test getData method
	//Test Setup: See Table 1
	//Input: defSub = "ENC", defSemester = "Spring", defCourseName = "English",
    //defCourseStart = "01/08/19", defCourseEnd = "05/01/19", defMonStart = "15:00", defMonEnd = "16:00", defTueStart = "15:00",
    //defTueEnd = "16:00", defWedStart = "15:00", defWedEnd = "16:00", defThuStart = "15:00", defThuEnd = "16:00",
    //defFriStart = "15:00", defFriEnd = "16:00", defSatStart = "15:00", defSatEnd = "16:00"
	//Expected Output: True, since we set all the values to the same ones in the array provided (allValues)
	
	@Test
	public void testGetData()
	{
		// Table 1
		String defSub = "ENC";
        String defSemester = "Spring";
        String defCourseName = "English";
        String defCourseStart = "01/08/19";
        String defCourseEnd = "05/01/19";
        String defMonStart = "15:00";
        String defMonEnd = "16:00";
        String defTueStart = "15:00";
        String defTueEnd = "16:00";
        String defWedStart = "15:00";
        String defWedEnd = "16:00";
        String defThuStart = "15:00";
        String defThuEnd = "16:00";
        String defFriStart = "15:00";
        String defFriEnd = "16:00";
        String defSatStart = "15:00";
        String defSatEnd = "16:00";
        
        String[] allValues =
        {
        	defSub,
        	defSemester,
        	defCourseName,
        	defCourseStart,
        	defCourseEnd,
        	defMonStart,
        	defMonEnd,
        	defTueStart,
        	defTueEnd,
        	defWedStart,
        	defWedEnd,
        	defThuStart,
        	defThuEnd,
        	defFriStart,
        	defFriEnd,
        	defSatStart,
        	defSatEnd
        };
        
		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);
		
		assertArrayEquals(allValues, controller.getDataValues());
	}
	
	//Test ID: PSM_Unit_Test_getData_Rainy_01
		//Purpose: Test getData method
		//Test Setup: See Table 1
		//Input: defSub = "", defSemester = "Spring", defCourseName = "English",
	    //defCourseStart = "01/08/19", defCourseEnd = "05/01/19", defMonStart = "15:00", defMonEnd = "16:00", defTueStart = "15:00",
	    //defTueEnd = "16:00", defWedStart = "15:00", defWedEnd = "16:00", defThuStart = "15:00", defThuEnd = "16:00",
	    //defFriStart = "15:00", defFriEnd = "16:00", defSatStart = "15:00", defSatEnd = "16:00"
		//Expected Output: Test failure, since one of the values returned by getData() is different from the ones in the test Database 
		
		@Test
		public void testGetDataRainy()
		{
			// Table 1
			String defSub = "";
	        String defSemester = "Spring";
	        String defCourseName = "English";
	        String defCourseStart = "01/08/19";
	        String defCourseEnd = "05/01/19";
	        String defMonStart = "15:00";
	        String defMonEnd = "16:00";
	        String defTueStart = "15:00";
	        String defTueEnd = "16:00";
	        String defWedStart = "15:00";
	        String defWedEnd = "16:00";
	        String defThuStart = "15:00";
	        String defThuEnd = "16:00";
	        String defFriStart = "15:00";
	        String defFriEnd = "16:00";
	        String defSatStart = "15:00";
	        String defSatEnd = "16:00";
	        
	        String[] allValues =
	        {
	        	defSub,
	        	defSemester,
	        	defCourseName,
	        	defCourseStart,
	        	defCourseEnd,
	        	defMonStart,
	        	defMonEnd,
	        	defTueStart,
	        	defTueEnd,
	        	defWedStart,
	        	defWedEnd,
	        	defThuStart,
	        	defThuEnd,
	        	defFriStart,
	        	defFriEnd,
	        	defSatStart,
	        	defSatEnd
	        };
	        
			when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
			when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
			when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
			when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
			when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
			when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
			when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
			when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
			when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
			when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
			when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
			when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
			when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
			when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
			when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
			when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
			when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);
			
			assertFalse(allValues.equals(controller.getDataValues()));
		}

	// NOT NECESSARY TO TEST THE sleep() FUNCTION AS IT
	// ONLY USES SYSTEM FUNCTIONS
	
		
	//Test ID: PSM_Unit_Test_testLogIn_Sunny_01
	//Purpose: Test the LogIn method
	//Test Setup: See Table 2
	//Input: user = "Whatever", pass = "1234"
	//Expected Output: True since the username and pass are valid
	@Test
	public void testLogInSunny()
	{
		// Table 2
		when(dbCon.connect("Whatever", "1234")).thenReturn(0);
		
		appController.LogIn(dbCon);
		assertTrue(controller.getLoggedIn());
	}
	
	//Test ID: PSM_Unit_Test_testLogIn_Rainy_01
	//Purpose: Test the LogIn method
	//Test Setup: See Table 2
	//Input: user = "", pass = ""
	//Expected Output: False since the username and pass are not valid
	@Test
	public void testLogInRainy()
	{
		// Table 2
		when(dbCon.connect("bad", "3333")).thenReturn(5);
		
		controller.LogIn(dbCon);
		assertFalse(controller.getLoggedIn());
	}
	//****************NEW TESTS****************
	//****************DELIVERABLE 2********
	//Test ID: PSM_Unit_Test_testLogIn_Sunny_01
	//Purpose: Test the LogIn method
	//Test Setup: See Table 2
	//Input: user = "Whatever", pass = "1234"
	//Expected Output: True since the username and pass are valid
	@Test
	public void testLogInSunny2()
	{
		// Table 2
		when(dbCon.connect("Whatever", "1234")).thenReturn(0);
			
		appController.LogIn();
		assertTrue(controller.getLoggedIn());
	}
	//****************NEW TESTS****************
	//****************DELIVERABLE 2********
	//Test ID: PSM_Unit_Test_testLogIn_Rainy_01
	//Purpose: Test the LogIn method
	//Test Setup: See Table 2
	//Input: user = "", pass = ""
	//Expected Output: False since the username and pass are not valid
	@Test
	public void testLogInRainy2()
	{
		// Table 2
		when(dbCon.connect("bad", "3333")).thenReturn(5);
			
		controller.LogIn();
		assertFalse(controller.getLoggedIn());
	}
	
	//Test ID: PSM_Unit_Test_testGetCon_Sunny_01
	//Purpose: Test the getCon method
	//Test Setup: A mock connection is set in appController.
	//Input: user = The mock connection
	//Expected Output: True since the the mock connection that was set in appController is the same being compared.
	@Test
	public void testGetConSunny()
	{
		assertEquals(dbCon, controller.getCon());
	}
	//Test ID: PSM_Unit_Test_testGetCon_Rainy_01
	//Purpose: Test the getCon method
	//Test Setup: A mock connection is set in appController.
	//Input: user = Another mock connection
	//Expected Output: False since the are two different mock connetions.
	@Test
	public void testGetConRainy()
	{
		DBConnection otherdbCon = mock(DBConnection.class);
		assertFalse(controller.compareTo(otherdbCon, controller.getCon()));
	}
	
	/*
	 * setTime(), getTime(), getTimeMillis() are NEVER
	 * used in the project, so they are not tested
	 */
	
	//Test ID: PSM_Unit_Test_TimerParse_Sunny_01
	//Purpose: Test the timerPraser
	//Test Setup: hr and min fields are null
	//Input: "10:30"
	//Expected Output: True for both since timeParser split 10:30 and assigns 10 to hr and 30 to min
	@Test
	public void testTimerParserSunny()
	{
		controller.timerParser("10:30");
		assertEquals(10, controller.returnHr());
		assertEquals(30, controller.returnMin());
	}
	
	//Test ID: PSM_Unit_Test_TimerParse_Rainy_01
	//Purpose: Test the timerPraser
	//Test Setup: hr and min fields are null
	//Input: "11:50"
	//Expected Output: False for both since timeParser split 11:50 and assigns 11 to hr and 50 to min but the comparison expected 10 and 30 respectively
	@Test
	public void testTimerParserRainy()
	{
		controller.timerParser("11:50");
		assertFalse(10 == controller.returnHr());
		assertFalse(30 == controller.returnMin());
	}
	//Test ID: PSM_Unit_Test_DateParser_Sunny_01
	//Purpose: Test the dateParser
	//Test Setup: clearMonth, ClearDate and ClearYear fields are null
	//Input: "01/01/19"
	//Expected Output: True for all three since dataParser splits "01/01/19" and assigns 01 to ClearMonth, 01 to CLearDate, and 19 to CLearYear
	@Test
	public void testDateParserSunny()
	{
		controller.dateParser("01/01/19");
		assertEquals(01, controller.getClearMonth());
		assertEquals(01, controller.getClearDate());
		assertEquals(19, controller.getClearYear());
	}
	//Test ID: PSM_Unit_Test_DateParser_Rainy_01
	//Purpose: Test the dateParser
	//Test Setup: clearMonth, ClearDate and ClearYear fields are null
	//Input: "01/01/19"
	//Expected Output: False for all three since dataParser splits "01/01/19" and assigns 01 to ClearMonth, 01 to CLearDate, and 19 to CLearYear
	//but the comparisons are 02, 02, 20 respesctevily.
	@Test
	public void testDateParserRainy()
	{
		controller.dateParser("01/01/19");
		assertFalse(02 == controller.getClearMonth());
		assertFalse(02 == controller.getClearDate());
		assertFalse(20 == controller.getClearYear());
	}
	//Test ID: PSM_Unit_Test_ReturnHr_Sunny_01
	//Purpose: Test the ReturnHr method
	//Test Setup: hr = 0
	//Input: 0
	//Expected Output: True 
	@Test
	public void testReturnHrSunny()
	{
		assertEquals(0, controller.returnHr());
	}
	//Test ID: PSM_Unit_Test_ReturnHr_Rainy_01
	//Purpose: Test the ReturnHr method
	//Test Setup: hr = 0
	//Input: 1
	//Expected Output: False 
	@Test
	public void testReturnHrRainy()
	{
		assertFalse(1 == controller.returnHr());
	}
	//Test ID: PSM_Unit_Test_ReturnMin_Sunny_01
	//Purpose: Test the ReturnMin method
	//Test Setup: min = 0
	//Input: 0
	//Expected Output: True
	@Test
	public void testReturnMinSunny()
	{
		assertEquals(0, controller.returnMin());
	}
	//Test ID: PSM_Unit_Test_ReturnMin_Sunny_01
	//Purpose: Test the ReturnMin method
	//Test Setup: min = 0
	//Input: 1
	//Expected Output: False
	@Test
	public void testReturnMinRainy()
	{
		assertFalse(1 == controller.returnMin());
	}
	
	//Test ID: PSM_Unit_Test_GetEndTime_Sunny_01
	//Purpose: Test the GetEndTime method
	//Test Setup: newC = new GregorianCalendar(), years = current, months = current,
	//			  dates = current
	//Input: years = newC.get(newC.YEAR), months = newC.get(newC.MONTH), dates = newC.get(newC.DATE),
	//		 newC.set(years, months, dates, 10, 30 - 1, 1), date = newC.getTime()
	//Expected Output: True because the end times are equal
	@Test
	public void testGetEndTimeSunny()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30 - 1, 1);
		
		Date date = newC.getTime();
		
		assertEquals(date, controller.getEndTime(10, 30));		
	}
	
	//Test ID: PSM_Unit_Test_GetEndTime_Rainy_01
	//Purpose: Test the GetEndTime method
	//Test Setup: newC = new GregorianCalendar(), years = current, months = current,
	//			  dates = current
	//Input: years = newC.get(newC.YEAR), months = newC.get(newC.MONTH), dates = newC.get(newC.DATE),
	//		 newC.set(years, months, dates, 10, 30, 1), date = newC.getTime()
	//Expected Output: False because the end times are not equal
	@Test
	public void testGetEndTimeRainy()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30, 1);
		
		Date date = newC.getTime();
		
		assertFalse(date.equals(controller.getEndTime(10, 30)));		
	}
	
	//Test ID: PSM_Unit_Test_SetSemesterClear_Sunny_01
	//Purpose: Test the SetSemesterClear method
	//Test Setup: autoClear = new GregorianCalendar(), autoClear.set(19, 01, 01, 10, 30)
	//Input: autoClear.set(19, 01, 01, 10, 30), date = autoClear.getTime(), setSemesterClear(19, 01, 01, 10, 30)
	//Expected Output: True because the semester clear times are equal
	
	@Test
	public void testSetSemesterClearSunny()
	{
		Calendar autoClear = new GregorianCalendar();
		
		autoClear.set(19, 01, 01, 10, 30);
		Date date = autoClear.getTime();		
		controller.setSemesterClear(19, 01, 01, 10, 30);
		
		// If the difference between the two times is
		// less than 10 seconds, the dates are equal. This
		// has to be done because calling getTime() takes
		// time, so the two times will never be exactly identical
		assertTrue((date.getTime() - controller.getDate2().getTime()) < 10000);
	}
	
	//Test ID: PSM_Unit_Test_SetSemesterClear_Sunny_01
	//Purpose: Test the SetSemesterClear method
	//Test Setup: autoClear = new GregorianCalendar(), autoClear.set(19, 01, 01, 10, 30)
	//Input: autoClear.set(19, 01, 01, 10, 30), date = autoClear.getTime(), setSemesterClear(20, 02, 02, 12, 40)
	//Expected Output: True because the semester clear times are equal
	@Test
	public void testSetSemesterClearRainy()
	{
		Calendar autoClear = new GregorianCalendar();
		
		autoClear.set(19, 01, 01, 10, 30);
		Date date = autoClear.getTime();		
		controller.setSemesterClear(20, 02, 02, 12, 40);
		
		// If the difference between the two times is
		// less than 10 seconds, the dates are equal. This
		// has to be done because calling getTime() takes
		// time, so the two times will never be exactly identical
		assertTrue((date.getTime() - controller.getDate2().getTime()) < 10000);
	}
	
	//Test ID: PSM_Unit_Test_GetSemesterClear_Sunny_01
	//Purpose: Test the GetSemesterClear method
	//Test Setup: autoClear = new GregorianCalendar()
	//Input: autoClear.getTime().getTime()
	//Expected Output: True because the semester clear times are equal
	@Test
	public void testGetSemesterClearSunny()
	{
		Calendar autoClear = new GregorianCalendar();
		//autoClear.set(19, 01, 01, 10, 30);
		
		
		assertTrue((autoClear.getTime().getTime() - controller.getAutoClear().getTime().getTime()) < 10000);
	}
	
	//Test ID: PSM_Unit_Test_GetSemesterClear_Rainy_01
	//Purpose: Test the GetSemesterClear method
	//Test Setup: autoClear = new GregorianCalendar()
	//Input: autoClear.getTime().getTime(), autoClear.set(19, 01, 01, 10, 30)
	//Expected Output: False because the semester clear times are NOT equal
	@Test
	public void testGetSemesterClearRainy()
	{
		Calendar autoClear = new GregorianCalendar();
		autoClear.set(2019, 01, 01, 11, 55);
		
		assertFalse((controller.getAutoClear().getTime().getTime()) - autoClear.getTime().getTime() < 10000);
	}
	
	//Test ID: PSM_Unit_Test_Get15BeforeEnd_Sunny_01
	//Purpose: Test the Get15BeforeEnd method
	//Test Setup: autoClear = new GregorianCalendar(), years = current, months = current, dates = current
	//Input: years = newC.get(newC.YEAR), months = newC.get(newC.MONTH), dates = newC.get(newC.DATE),
	//		 newC.set(years, months, dates, 10, 30 - 15, 1), date = newC.getTime()
	//Expected Output: True because the end times are equal
	@Test
	public void testGet15BeforeEndSunny()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30 - 15, 1);
		
		Date date = newC.getTime();
		
		assertEquals(date, controller.get15BeforeEnd(10, 30));
	}
	
	//Test ID: PSM_Unit_Test_Get15BeforeEnd_Rainy_01
	//Purpose: Test the Get15BeforeEnd method
	//Test Setup: autoClear = new GregorianCalendar(), years = current, months = current, dates = current
	//Input: years = newC.get(newC.YEAR), months = newC.get(newC.MONTH), dates = newC.get(newC.DATE),
	//		 newC.set(years, months, dates, 10, 30, 1), date = newC.getTime()
	//Expected Output: False because the end times are NOT equal
	@Test
	public void testGet15BeforeEndRainy()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30, 1);
		
		Date date = newC.getTime();
		
		assertFalse(date.equals(controller.get15BeforeEnd(10, 30)));
	}
	
	//Test ID: PSM_Unit_Test_Get5BeforeEnd_Sunny_01
	//Purpose: Test the Get5BeforeEnd method
	//Test Setup: autoClear = new GregorianCalendar(), years = current, months = current, dates = current
	//Input: years = newC.get(newC.YEAR), months = newC.get(newC.MONTH), dates = newC.get(newC.DATE),
	//		 newC.set(years, months, dates, 10, 30 - 5, 1), date = newC.getTime()
	//Expected Output: True because the end times are equal
	
	@Test
	public void testGet5BeforeEndSunny()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30 - 5, 1);
		
		Date date = newC.getTime();
		
		assertEquals(date, controller.get5BeforeEnd(10, 30));
	}
	
	//Test ID: PSM_Unit_Test_Get5BeforeEnd_Rainy_01
	//Purpose: Test the Get5BeforeEnd method
	//Test Setup: autoClear = new GregorianCalendar(), years = current, months = current, dates = current
	//Input: years = newC.get(newC.YEAR), months = newC.get(newC.MONTH), dates = newC.get(newC.DATE),
	//		 newC.set(years, months, dates, 10, 30, 1), date = newC.getTime()
	//Expected Output: False because the end times are NOT equal
	
	@Test
	public void testGet5BeforeEndRainy()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30, 1);
		
		Date date = newC.getTime();
		
		assertFalse(date.equals(controller.get5BeforeEnd(10, 30)));
	}
	//Test ID: PSM_Unit_Test_GLoggedin_Sunny_01
	//Purpose: Test the loggedin method
	//Test Setup: user = "user1", password = "1234"
	//Input: authenticate returns true
	//Expected Output: True
	@Test
	public void testLoggedinSunny() {
		doNothing().when(icMock).Initiate_Login_Form();
		icMock.log = logMock;
		when(icMock.log.dataReceived()).thenReturn(true);
		when(icMock.log.getUsername()).thenReturn("user1");
		when(icMock.log.getPassword()).thenReturn("1234");
		when(authMock.validate_Login()).thenReturn(true);
		when(dbCon.connect("user1", "1234")).thenReturn(0);
		//skipp (!loggedin)
		//skip (counter >= 3)
		assertTrue(controller.loggedin());
		
	}
	
	//Test ID: PSM_Unit_Test_GLoggedin_Rainy_01
	//Purpose: Test the loggedin method
	//Test Setup: user = "user1", password = "1234"
	//Input: authenticate returns false
	//Expected Output: true
	@Test
	public void testLoggedinRainy() {
		doNothing().when(icMock).Initiate_Login_Form();
		icMock.log = logMock;
		icMock.msg = msgMock;
		when(icMock.log.dataReceived()).thenReturn(true);
		when(icMock.log.getUsername()).thenReturn("user1");
		when(icMock.log.getPassword()).thenReturn("1234");
		when(authMock.validate_Login()).thenReturn(false);
		when(dbCon.connect("user1", "1234")).thenReturn(0);
		doNothing().when(icMock).Initiate_IncorrectLogin();
		icMock.msg.ack = true;
		
		assertTrue(controller.loggedin());
		
	}
	
	@Test
	public void testAutoClear() {
		controller.autoClear();
	}
	
	@Test
	public void testAutoExit() {
		controller.autoExit();
	}
	
	@Test
	public void testGetSemesterClear() {
		Date date2 = new Date();
		Date date = controller.getSemesterClear();
		assertFalse(date2.equals(date));
	}
	
	
}