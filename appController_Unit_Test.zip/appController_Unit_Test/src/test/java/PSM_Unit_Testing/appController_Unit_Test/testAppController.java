package PSM_Unit_Testing.appController_Unit_Test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import my.PSM.PSM_Interface.LoginForm;
import my.PSM.PSM_Interface.Messages;
import my.PSM.PSM_Logic.Authenticate;
import my.PSM.PSM_Logic.InterfaceController;
import my.PSM.PSM_Storage.DBConnection;

public class testAppController {

	@Mock
	Connection connection;
	@Mock
	Statement statement;
	@Mock
	DBConnection dbCon;
	@Mock
	InterfaceController icMock;
	@Mock
	Authenticate authMock;
	@Mock
	LoginForm logMock;
	@Mock
	Messages msgMock;

	
	appController controller;
	
	@Before
	public void setUp() throws Exception {
		controller = new appController();
		
		dbCon = mock(DBConnection.class);
		statement = mock(Statement.class);
		connection = mock(Connection.class);
		authMock = mock(Authenticate.class);
		icMock = mock(InterfaceController.class);
		logMock = mock(LoginForm.class);
		msgMock = mock(Messages.class);
		
		controller.setDB(dbCon);
		controller.setAuthenticate(authMock);
		controller.setInterfaceController(icMock);
	}

	@After
	public void tearDown() throws Exception {
		controller = null;
	}

	@Test
	public void testCheckClear() {
		ArrayList<String> date = new ArrayList<String>();
		date.add("01/08/19");
		date.add("01/08/19");
		date.add("01/08/19");
		
		when(dbCon.getEndDates()).thenReturn(date);
		assertTrue(controller.checkClear());
		verify(dbCon).getEndDates();
	}
	@Test
	public void testCheckTimes() {
		ArrayList<Integer> date = new ArrayList<Integer>();
		date.add(1101);
		
		String defSub = "ENC";
        String defSemester = "Spring";
        String defCourseName = "English";
        String defCourseStart = "01/08/19";
        String defCourseEnd = "05/01/19";
        String defMonStart = "15:00";
        String defMonEnd = "16:00";
        String defTueStart = "15:00";
        String defTueEnd = "16:00";
        String defWedStart = "15:00";
        String defWedEnd = "16:00";
        String defThuStart = "15:00";
        String defThuEnd = "16:00";
        String defFriStart = "15:00";
        String defFriEnd = "16:00";
        String defSatStart = "15:00";
        String defSatEnd = "16:00";
        
		when(dbCon.getCourses()).thenReturn(date);
		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);
		
		assertFalse(controller.checkTimes());
	}
	
	@Test
	public void testGetData()
	{
		String defSub = "ENC";
        String defSemester = "Spring";
        String defCourseName = "English";
        String defCourseStart = "01/08/19";
        String defCourseEnd = "05/01/19";
        String defMonStart = "15:00";
        String defMonEnd = "16:00";
        String defTueStart = "15:00";
        String defTueEnd = "16:00";
        String defWedStart = "15:00";
        String defWedEnd = "16:00";
        String defThuStart = "15:00";
        String defThuEnd = "16:00";
        String defFriStart = "15:00";
        String defFriEnd = "16:00";
        String defSatStart = "15:00";
        String defSatEnd = "16:00";
        
        String[] allValues =
        {
        	defSub,
        	defSemester,
        	defCourseName,
        	defCourseStart,
        	defCourseEnd,
        	defMonStart,
        	defMonEnd,
        	defTueStart,
        	defTueEnd,
        	defWedStart,
        	defWedEnd,
        	defThuStart,
        	defThuEnd,
        	defFriStart,
        	defFriEnd,
        	defSatStart,
        	defSatEnd
        };
        
		when(dbCon.fetchCourseSubj(1101)).thenReturn(defSub);
		when(dbCon.fetchCourseSemester(1101)).thenReturn(defSemester);
		when(dbCon.fetchCourseName(1101)).thenReturn(defCourseName);
		when(dbCon.fetchCourseStart(1101)).thenReturn(defCourseStart);
		when(dbCon.fetchCourseEnd(1101)).thenReturn(defCourseEnd);
		when(dbCon.fetchStartMon(1101)).thenReturn(defMonStart);
		when(dbCon.fetchEndMon(1101)).thenReturn(defMonEnd);
		when(dbCon.fetchStartTue(1101)).thenReturn(defTueStart);
		when(dbCon.fetchEndTue(1101)).thenReturn(defTueEnd);
		when(dbCon.fetchStartWed(1101)).thenReturn(defWedStart);
		when(dbCon.fetchEndWed(1101)).thenReturn(defWedEnd);
		when(dbCon.fetchStartThu(1101)).thenReturn(defThuStart);
		when(dbCon.fetchEndThu(1101)).thenReturn(defThuEnd);
		when(dbCon.fetchStartFri(1101)).thenReturn(defFriStart);
		when(dbCon.fetchEndFri(1101)).thenReturn(defFriEnd);
		when(dbCon.fetchStartSat(1101)).thenReturn(defSatStart);
		when(dbCon.fetchEndSat(1101)).thenReturn(defSatEnd);
		
		assertArrayEquals(allValues, controller.getDataValues());
	}

	// NOT NECESSARY TO TEST THE sleep() FUNCTION AS IT
	// ONLY USES SYSTEM FUNCTIONS
	
	@Test
	public void testLogIn()
	{
		when(dbCon.connect("Whatever", "1234")).thenReturn(0);
		controller.LogIn();
		assertTrue(controller.getLoggedIn());
	}
	
	@Test
	public void testGetCon()
	{
		assertEquals(dbCon, controller.getCon());
	}
	
	/*
	 * setTime(), getTime(), getTimeMillis() are NEVER
	 * used in the project, so they are not tested
	 */
	
	@Test
	public void testTimerParser()
	{
		controller.timerParser("10:30");
		assertEquals(10, controller.returnHr());
		assertEquals(30, controller.returnMin());
	}
	
	@Test
	public void testDateParser()
	{
		controller.dateParser("01/01/19");
		assertEquals(01, controller.getClearMonth());
		assertEquals(01, controller.getClearDate());
		assertEquals(19, controller.getClearYear());
	}
	
	@Test
	public void testReturnHr()
	{
		assertEquals(0, controller.returnHr());
	}
	
	@Test
	public void testReturnMin()
	{
		assertEquals(0, controller.returnMin());
	}
	
	@Test
	public void testGetEndTime()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30 - 1, 1);
		
		Date date = newC.getTime();
		
		assertEquals(date, controller.getEndTime(10, 30));		
	}
	
	@Test
	public void testSetSemesterClear()
	{
		Calendar autoClear = new GregorianCalendar();
		
		autoClear.set(19, 01, 01, 10, 30);
		Date date = autoClear.getTime();		
		controller.setSemesterClear(19, 01, 01, 10, 30);
		
		// If the difference between the two times is
		// less than 10 seconds, the dates are equal. This
		// has to be done because calling getTime() takes
		// time, so the two times will never be exactly identical
		assertTrue((date.getTime() - controller.getDate2().getTime()) < 10000);
	}
	
	@Test
	public void testGetSemesterClear()
	{
		Calendar autoClear = new GregorianCalendar();
		//autoClear.set(19, 01, 01, 10, 30);
		
		
		assertTrue((autoClear.getTime().getTime() - controller.getAutoClear().getTime().getTime()) < 10000);
	}
	
	@Test
	public void testGet15BeforeEnd()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30 - 15, 1);
		
		Date date = newC.getTime();
		
		assertEquals(date, controller.get15BeforeEnd(10, 30));
	}
	
	@Test
	public void testGet5BeforeEnd()
	{
		Calendar newC = new GregorianCalendar();
		int years, months, dates, dayOfWeek;
		
		years = newC.get(newC.YEAR);
		months = newC.get(newC.MONTH);
		dates = newC.get(newC.DATE);
		
		newC.set(years, months, dates, 10, 30 - 5, 1);
		
		Date date = newC.getTime();
		
		assertEquals(date, controller.get5BeforeEnd(10, 30));
	}
	
	@Test
	public void testLoggedin1() {
		doNothing().when(icMock).Initiate_Login_Form();
		icMock.log = logMock;
		when(icMock.log.dataReceived()).thenReturn(true);
		when(icMock.log.getUsername()).thenReturn("user1");
		when(icMock.log.getPassword()).thenReturn("1234");
		when(authMock.validate_Login()).thenReturn(true);
		when(dbCon.connect("user1", "1234")).thenReturn(0);
		//skipp (!loggedin)
		//skip (counter >= 3)
		controller.loggedin();
		
	}
	
	@Test
	public void testLoggedin2() {
		doNothing().when(icMock).Initiate_Login_Form();
		icMock.log = logMock;
		icMock.msg = msgMock;
		when(icMock.log.dataReceived()).thenReturn(true);
		when(icMock.log.getUsername()).thenReturn("user1");
		when(icMock.log.getPassword()).thenReturn("1234");
		when(authMock.validate_Login()).thenReturn(false);
		when(dbCon.connect("user1", "1234")).thenReturn(0);
		doNothing().when(icMock).Initiate_IncorrectLogin();
		icMock.msg.ack = true;
		
		controller.loggedin();
		
	}
	
	
}